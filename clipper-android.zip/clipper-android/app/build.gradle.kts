plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.free.clipper"
    compileSdk = 34
    defaultConfig { applicationId = "com.free.clipper"; minSdk = 29; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17"; freeCompilerArgs += "-opt-in=androidx.media3.common.util.UnstableApi" }
    lint { abortOnError = false }
}
dependencies {
    val m = "1.4.1"
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.media3:media3-exoplayer:$m")
    implementation("androidx.media3:media3-ui:$m")
    implementation("androidx.media3:media3-transformer:$m")
    implementation("androidx.media3:media3-effect:$m")
    implementation("androidx.media3:media3-common:$m")
}
