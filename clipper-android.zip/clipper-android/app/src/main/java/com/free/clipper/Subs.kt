package com.free.clipper

import android.graphics.*
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.BitmapOverlay

data class W(val s: Long, val e: Long, val t: String)
data class Cap(val s: Long, val e: Long, val t: String, val w: List<W> = emptyList())

/** Snapshot of subtitle look used while exporting */
class CapStyle(val tf: Typeface, val sizeFrac: Float, val mode: Int, val base: Int, val hi: Int, val pal: IntArray,
               val outFrac: Float, val outCol: Int, val shadow: Boolean, val bg: Int, val upper: Boolean, val y: Float)

object Subs {
    val COLS = listOf(0xFFFFFFFF, 0xFFFFE600, 0xFFFF3B30, 0xFF34C759, 0xFF00E5FF, 0xFFFF9500, 0xFFFF2D95, 0xFFAF52DE, 0xFF0A84FF, 0xFFA6FF00, 0xFFFFD700, 0xFF000000).map { it.toInt() }
    val PAL_NAMES = listOf("Classic (white / yellow)", "Neon (cyan / pink / lime)", "Fire (orange / red / gold)", "Candy (pink / cyan / yellow / white)")
    val PALS = listOf(
        intArrayOf(COLS[0], COLS[1]), intArrayOf(COLS[4], COLS[6], COLS[9]), intArrayOf(COLS[5], COLS[2], COLS[10]), intArrayOf(COLS[6], COLS[4], COLS[1], COLS[0]))
    val FONT_NAMES = listOf("Bold Sans", "Heavy", "Condensed", "Serif", "Casual", "Handwriting", "Mono", "Medium", "My font (import)")
    fun typeface(i: Int, custom: Typeface?): Typeface = when (i) {
        0 -> Typeface.create("sans-serif", Typeface.BOLD)
        1 -> Typeface.create("sans-serif-black", Typeface.NORMAL)
        2 -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
        3 -> Typeface.create("serif", Typeface.BOLD)
        4 -> Typeface.create("casual", Typeface.NORMAL)
        5 -> Typeface.create("cursive", Typeface.NORMAL)
        6 -> Typeface.create("monospace", Typeface.BOLD)
        7 -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
        else -> custom ?: Typeface.create("sans-serif", Typeface.BOLD)
    }

    /** Draws words (each with its own colour) wrapped to maxW, with outline / shadow / background box */
    fun render(words: List<String>, cols: IntArray, tf: Typeface, px: Float, maxW: Int, outW: Float, outCol: Int, shadow: Boolean, bg: Int): Bitmap {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = tf; textSize = px }
        val sp = p.measureText(" "); val ws = words.map { p.measureText(it) }
        val lines = ArrayList<ArrayList<Int>>(); var cur = ArrayList<Int>(); var cw = 0f
        for (i in words.indices) {
            val add = if (cur.isEmpty()) ws[i] else sp + ws[i]
            if (cur.isNotEmpty() && cw + add > maxW) { lines.add(cur); cur = ArrayList(); cw = 0f }
            cw += if (cur.isEmpty()) ws[i] else sp + ws[i]; cur.add(i)
        }
        if (cur.isNotEmpty()) lines.add(cur)
        val lw = lines.map { l -> l.sumOf { ws[it].toDouble() }.toFloat() + sp * (l.size - 1) }
        val fm = p.fontMetrics; val lh = (fm.descent - fm.ascent) * 1.08f; val pad = px * 0.3f + outW
        val bw = ((lw.maxOrNull() ?: 1f) + 2 * pad).toInt().coerceAtLeast(2); val bh = (lines.size * lh + 2 * pad).toInt().coerceAtLeast(2)
        val bm = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888); val c = Canvas(bm)
        if (Color.alpha(bg) > 0) { p.style = Paint.Style.FILL; p.color = bg; c.drawRoundRect(0f, 0f, bw.toFloat(), bh.toFloat(), px * 0.3f, px * 0.3f, p) }
        lines.forEachIndexed { li, l ->
            var x = (bw - lw[li]) / 2; val y = pad + li * lh - fm.ascent
            for (i in l) {
                if (shadow) { p.style = Paint.Style.FILL; p.color = 0x77000000; c.drawText(words[i], x + px * 0.04f, y + px * 0.06f, p) }
                if (outW > 0f) { p.style = Paint.Style.STROKE; p.strokeWidth = outW * 2; p.strokeJoin = Paint.Join.ROUND; p.color = outCol; c.drawText(words[i], x, y, p) }
                p.style = Paint.Style.FILL; p.color = cols[i]; c.drawText(words[i], x, y, p)
                x += ws[i] + sp
            }
        }
        return bm
    }

    fun colorsFor(n: Int, mode: Int, wi: Int, base: Int, hi: Int, pal: IntArray) = IntArray(n) { i -> when (mode) { 1 -> pal[i % pal.size]; 2 -> if (i == wi) hi else base; else -> base } }
}

/** Subtitle overlay: re-renders only when the caption or the highlighted word changes */
class CapOverlay(private val caps: List<Cap>, private val clipStart: Long, private val speed: Float, private val ow: Int, private val st: CapStyle) : BitmapOverlay() {
    private val blank = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888); private var key = -2L; private var bmp = blank
    private val settings = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, st.y).build()
    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val m = (presentationTimeUs / 1000.0 * speed).toLong() + clipStart
        val i = caps.indexOfFirst { m >= it.s && m <= it.e }
        if (i < 0) { key = -1; return blank }
        val cap = caps[i]; val wi = if (st.mode == 2 && cap.w.isNotEmpty()) cap.w.indexOfLast { m >= it.s }.coerceAtLeast(0) else 0
        val k = i * 100L + wi
        if (k != key) {
            key = k
            val ws = (if (cap.w.isNotEmpty()) cap.w.map { it.t } else cap.t.replace("\n", " ").split(" ").filter { it.isNotEmpty() }).map { if (st.upper) it.uppercase() else it }
            val px = ow * st.sizeFrac
            bmp = Subs.render(ws, Subs.colorsFor(ws.size, st.mode, wi, st.base, st.hi, st.pal), st.tf, px, (ow * 0.9f).toInt(), st.outFrac * px, st.outCol, st.shadow, st.bg)
        }
        return bmp
    }
    override fun getOverlaySettings(presentationTimeUs: Long) = settings
}

/** Devanagari -> Roman (Hinglish) transliteration for Hindi speech */
object Hinglish {
    private val cons = mapOf('क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "ng", 'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "ny", 'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n", 'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m", 'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh", 'स' to "s", 'ह' to "h", 'ळ' to "l")
    private val indep = mapOf('अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "ee", 'उ' to "u", 'ऊ' to "oo", 'ऋ' to "ri", 'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au")
    private val matra = mapOf('ा' to "aa", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo", 'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au")
    private val nukta = mapOf('क' to "q", 'ख' to "kh", 'ग' to "gh", 'ज' to "z", 'ड' to "r", 'ढ' to "rh", 'फ' to "f")
    private const val LABIAL = "पफबभम"
    private class U(val t: Char, val b: String, val mt: String?, val vir: Boolean, val ch: Char)

    private fun word(w: String): String {
        val us = ArrayList<U>(); var i = 0; val n = w.length
        while (i < n) {
            val ch = w[i]
            if (cons.containsKey(ch)) {
                var base = cons[ch]!!; i++
                if (i < n && w[i] == '़') { base = nukta[ch] ?: base; i++ }
                var mt: String? = null; var vir = false
                if (i < n && w[i] == '्') { vir = true; i++ } else if (i < n && matra.containsKey(w[i])) { mt = matra[w[i]]; i++ }
                us.add(U('C', base, mt, vir, ch))
            } else if (indep.containsKey(ch)) { us.add(U('V', indep[ch]!!, null, false, ch)); i++ }
            else if (ch == 'ं' || ch == 'ँ') { us.add(U('N', "n", null, false, ch)); i++ }
            else if (ch == 'ः') { us.add(U('O', "h", null, false, ch)); i++ }
            else if (ch in '०'..'९') { us.add(U('O', (ch - '०').toString(), null, false, ch)); i++ }
            else if (ch == '।') { us.add(U('O', ".", null, false, ch)); i++ }
            else { us.add(U('O', ch.toString(), null, false, ch)); i++ }
        }
        val sb = StringBuilder()
        for (u in us.indices) {
            val x = us[u]; val isEnd = u == us.size - 1; val onlyNasalAfter = us.subList(u + 1, us.size).all { it.t == 'N' }
            when (x.t) {
                'C' -> {
                    sb.append(x.b)
                    if (x.vir) { }
                    else if (x.mt != null) {
                        var m: String = x.mt
                        if (onlyNasalAfter && us.size - 1 == u) m = when (m) { "aa" -> "a"; "ee" -> "i"; "oo" -> "u"; else -> m }
                        else if (onlyNasalAfter && m == "ee") m = "i"
                        sb.append(m)
                    } else if (!isEnd) {
                        val nx = us[u + 1]
                        val del = u > 0 && nx.t == 'C' && nx.mt != null && !nx.vir
                        if (!del) sb.append('a')
                    }
                }
                'V' -> sb.append(x.b)
                'N' -> { val nx = us.getOrNull(u + 1); sb.append(if (nx != null && nx.t == 'C' && LABIAL.indexOf(nx.ch) >= 0) "m" else "n") }
                else -> sb.append(x.b)
            }
        }
        return sb.toString()
    }

    fun translit(s: String): String {
        val sb = StringBuilder(); var i = 0
        while (i < s.length) {
            if (s[i] in '\u0900'..'\u097F') { var j = i; while (j < s.length && s[j] in '\u0900'..'\u097F') j++; sb.append(word(s.substring(i, j))); i = j }
            else { sb.append(s[i]); i++ }
        }
        return sb.toString()
    }
}
