package com.free.clipper

import android.content.Context
import android.graphics.RectF
import android.opengl.GLES20
import androidx.media3.common.util.Size
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

enum class Layout { SINGLE, SPLIT, TRIPLE, PIP }
/** out and src are normalized rects (left, top, right, bottom), top-left origin */
class Layer(val out: RectF, val src: RectF)

fun buildLayers(vw: Int, vh: Int, regs: List<RectF>, layout: Layout, split: Float, swap: Boolean, ow: Int, oh: Int): List<Layer> {
    val r = if (swap) regs.reversed() else regs
    fun cover(reg: RectF, out: RectF): RectF {
        val rw = reg.width() * vw; val rh = reg.height() * vh
        val sc = maxOf(out.width() * ow / rw, out.height() * oh / rh)
        val sw = out.width() * ow / sc; val sh = out.height() * oh / sc
        val sx = (reg.centerX() * vw - sw / 2).coerceIn(0f, vw - sw); val sy = (reg.centerY() * vh - sh / 2).coerceIn(0f, vh - sh)
        return RectF(sx / vw, sy / vh, (sx + sw) / vw, (sy + sh) / vh)
    }
    val pip = layout == Layout.PIP && r.size >= 2
    val outs: List<RectF> = when {
        pip -> {
            val ar = (r[0].width() * vw) / (r[0].height() * vh); val pw = 0.42f
            val ph = minOf(0.3f, pw * ow / (ar * oh))
            listOf(RectF(0f, 0f, 1f, 1f), RectF(0.55f, 0.04f, 0.97f, 0.04f + ph))
        }
        layout == Layout.SPLIT && r.size >= 2 -> listOf(RectF(0f, 0f, 1f, split), RectF(0f, split, 1f, 1f))
        layout == Layout.TRIPLE && r.size >= 3 -> { val h2 = (1f - split) / 2; listOf(RectF(0f, 0f, 1f, split), RectF(0f, split, 1f, split + h2), RectF(0f, split + h2, 1f, 1f)) }
        else -> listOf(RectF(0f, 0f, 1f, 1f))
    }
    val order = if (pip) listOf(r[1], r[0]) else r
    return outs.mapIndexed { i, o -> Layer(o, cover(order[i], o)) }
}

class LayoutEffect(val regs: List<RectF>, val layout: Layout, val split: Float, val swap: Boolean, val ow: Int, val oh: Int) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram = LayoutShader(this)
}

class LayoutShader(private val e: LayoutEffect) : BaseGlShaderProgram(false, 1) {
    private var layers = emptyList<Layer>()
    private val prog: GlProgram
    init {
        val vs = "attribute vec4 aFramePosition;varying vec2 v;void main(){gl_Position=aFramePosition;v=aFramePosition.xy*0.5+0.5;}"
        val sb = StringBuilder("precision highp float;uniform sampler2D uTexSampler;varying vec2 v;uniform vec4 o0,o1,o2,s0,s1,s2;uniform float n;void main(){vec4 c=vec4(0.,0.,0.,1.);")
        for (i in 0..2) sb.append("if(n>${i}.5&&v.x>=o$i.x&&v.x<=o$i.x+o$i.z&&v.y>=o$i.y&&v.y<=o$i.y+o$i.w){c=texture2D(uTexSampler,s$i.xy+(v-o$i.xy)/o$i.zw*s$i.zw);}")
        sb.append("gl_FragColor=c;}")
        prog = try { GlProgram(vs, sb.toString()) } catch (x: Exception) { throw VideoFrameProcessingException(x) }
    }
    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        layers = buildLayers(inputWidth, inputHeight, e.regs, e.layout, e.split, e.swap, e.ow, e.oh)
        return Size(e.ow, e.oh)
    }
    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            GLES20.glClearColor(0f, 0f, 0f, 1f); GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            prog.use(); prog.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            for (i in 0..2) {
                val l = layers.getOrNull(i)
                prog.setFloatsUniform("o$i", if (l == null) FloatArray(4) else floatArrayOf(l.out.left, 1f - l.out.bottom, l.out.width(), l.out.height()))
                prog.setFloatsUniform("s$i", if (l == null) floatArrayOf(0f, 0f, 1f, 1f) else floatArrayOf(l.src.left, 1f - l.src.bottom, l.src.width(), l.src.height()))
            }
            prog.setFloatUniform("n", layers.size.toFloat())
            prog.setBufferAttribute("aFramePosition", GlUtil.getNormalizedCoordinateBounds(), GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE)
            prog.bindAttributesAndUniforms(); GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (x: Exception) { throw VideoFrameProcessingException(x, presentationTimeUs) }
    }
    override fun release() { super.release(); try { prog.delete() } catch (_: Exception) {} }
}
