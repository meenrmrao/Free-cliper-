package com.free.clipper

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.opengl.GLES20
import androidx.media3.common.C
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Colour + clarity settings (identity = no change) */
class Grade(var den: Float = 0f, var shp: Float = 0f, var blk: Float = 0f, var wht: Float = 1f, var gam: Float = 1f, var con: Float = 1f,
            var sat: Float = 1f, var vig: Float = 0f, var bri: Float = 0f, var gry: Float = 0f, var gr: Float = 1f, var gg: Float = 1f, var gb: Float = 1f) {
    fun copyOf() = Grade(den, shp, blk, wht, gam, con, sat, vig, bri, gry, gr, gg, gb)
    fun isIdentity() = den == 0f && shp == 0f && blk == 0f && wht == 1f && gam == 1f && con == 1f && sat == 1f && vig == 0f && bri == 0f && gry == 0f && gr == 1f && gg == 1f && gb == 1f
}

val PRESET_NAMES = listOf("Original", "Cinematic", "Vibrant", "Warm", "Cool", "B&W", "Vintage", "Clean & Sharp")
fun presetGrade(i: Int): Grade = when (i) {
    1 -> Grade(con = 1.15f, sat = 0.92f, gr = 1.04f, gb = 0.96f, vig = 0.25f, blk = 0.03f)
    2 -> Grade(sat = 1.35f, con = 1.1f, shp = 0.3f)
    3 -> Grade(gr = 1.08f, gb = 0.92f, sat = 1.05f)
    4 -> Grade(gr = 0.92f, gb = 1.08f)
    5 -> Grade(gry = 1f, con = 1.15f)
    6 -> Grade(sat = 0.75f, gr = 1.06f, gb = 0.9f, vig = 0.35f, blk = 0.04f, con = 0.95f, bri = 0.03f)
    7 -> Grade(den = 0.35f, shp = 0.5f, con = 1.05f)
    else -> Grade()
}

/** One-click auto colour: samples frames, fixes levels, white balance, exposure, saturation + adds light clean-up/sharpen */
fun autoGrade(ctx: Context, u: Uri, dur: Long, prog: (Int) -> Unit): Grade {
    val mr = MediaMetadataRetriever(); mr.setDataSource(ctx, u)
    val hist = IntArray(256); var sr = 0.0; var sg = 0.0; var sb = 0.0; var ss = 0.0; var cnt = 0L; val k = 10
    try {
        for (i in 0 until k) {
            prog(i * 100 / k)
            val bm = mr.getScaledFrameAtTime((dur * (i + 0.5) / k).toLong() * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 160, 160) ?: continue
            val px = IntArray(bm.width * bm.height); bm.getPixels(px, 0, bm.width, 0, 0, bm.width, bm.height)
            for (p in px) {
                val r = ((p shr 16) and 255) / 255.0; val g = ((p shr 8) and 255) / 255.0; val b = (p and 255) / 255.0
                val l = 0.299 * r + 0.587 * g + 0.114 * b; hist[(l * 255).toInt().coerceIn(0, 255)]++
                sr += r; sg += g; sb += b; val mx = max(r, max(g, b)); val mn = min(r, min(g, b)); ss += if (mx > 0) (mx - mn) / mx else 0.0; cnt++
            }
            bm.recycle()
        }
    } finally { mr.release() }
    if (cnt == 0L) return Grade()
    fun pct(f: Double): Double { var c = 0L; for (i in 0..255) { c += hist[i]; if (c >= cnt * f) return i / 255.0 }; return 1.0 }
    val mR = sr / cnt; val mG = sg / cnt; val mB = sb / cnt; val y = 0.299 * mR + 0.587 * mG + 0.114 * mB; val meanSat = ss / cnt
    val g = Grade()
    g.blk = pct(0.02).coerceIn(0.0, 0.12).toFloat(); g.wht = pct(0.98).coerceIn(0.8, 1.0).toFloat()
    g.gr = (1 + 0.5 * (y / max(mR, 0.02) - 1)).coerceIn(0.9, 1.12).toFloat()
    g.gg = (1 + 0.5 * (y / max(mG, 0.02) - 1)).coerceIn(0.9, 1.12).toFloat()
    g.gb = (1 + 0.5 * (y / max(mB, 0.02) - 1)).coerceIn(0.9, 1.12).toFloat()
    val ml = ((y - g.blk) / max(g.wht - g.blk, 0.1f)).coerceIn(0.05, 0.95)
    g.gam = (ln(0.46) / ln(ml)).coerceIn(0.75, 1.35).toFloat()
    g.sat = (0.36 / max(meanSat, 0.05)).coerceIn(0.95, 1.3).toFloat()
    g.con = 1.06f; g.shp = 0.35f; g.den = 0.25f
    return g
}

class EnhanceEffect(val g: Grade) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram = EnhanceShader(g)
}

class EnhanceShader(private val g: Grade) : BaseGlShaderProgram(false, 1) {
    private val prog: GlProgram; private var w = 1; private var h = 1
    init {
        val vs = "attribute vec4 aFramePosition;varying vec2 v;void main(){gl_Position=aFramePosition;v=aFramePosition.xy*0.5+0.5;}"
        val fs = "precision highp float;uniform sampler2D uTexSampler;varying vec2 v;uniform vec2 px;uniform vec3 gain;" +
            "uniform float den,shp,blk,wht,gam,con,sat,vig,bri,gry;" +
            "void main(){vec3 c=texture2D(uTexSampler,v).rgb;vec3 acc=c;float ws=1.0;vec3 nb=c;" +
            "for(int i=-1;i<=1;i++){for(int j=-1;j<=1;j++){if(i==0&&j==0)continue;" +
            "vec3 s=texture2D(uTexSampler,v+vec2(float(i),float(j))*px).rgb;vec3 d=s-c;float wt=exp(-dot(d,d)*60.0);acc+=s*wt;ws+=wt;nb+=s;}}" +
            "vec3 bl=nb/9.0;c=mix(c,acc/ws,den);c=c+(c-bl)*shp*1.5;" +
            "c=clamp((c-blk)/max(wht-blk,0.1),0.0,1.0);c*=gain;c=pow(clamp(c,0.0,1.0),vec3(gam));" +
            "c=(c-0.5)*con+0.5+bri;float l=dot(c,vec3(0.299,0.587,0.114));c=mix(vec3(l),c,sat);c=mix(c,vec3(l),gry);" +
            "float d2=distance(v,vec2(0.5));c*=1.0-vig*smoothstep(0.35,0.85,d2);gl_FragColor=vec4(clamp(c,0.0,1.0),1.0);}"
        prog = try { GlProgram(vs, fs) } catch (x: Exception) { throw VideoFrameProcessingException(x) }
    }
    override fun configure(inputWidth: Int, inputHeight: Int): Size { w = inputWidth; h = inputHeight; return Size(w, h) }
    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            GLES20.glClearColor(0f, 0f, 0f, 1f); GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            prog.use(); prog.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            prog.setFloatsUniform("px", floatArrayOf(1f / w, 1f / h)); prog.setFloatsUniform("gain", floatArrayOf(g.gr, g.gg, g.gb))
            prog.setFloatUniform("den", g.den); prog.setFloatUniform("shp", g.shp); prog.setFloatUniform("blk", g.blk); prog.setFloatUniform("wht", g.wht)
            prog.setFloatUniform("gam", g.gam); prog.setFloatUniform("con", g.con); prog.setFloatUniform("sat", g.sat); prog.setFloatUniform("vig", g.vig)
            prog.setFloatUniform("bri", g.bri); prog.setFloatUniform("gry", g.gry)
            prog.setBufferAttribute("aFramePosition", GlUtil.getNormalizedCoordinateBounds(), GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE)
            prog.bindAttributesAndUniforms(); GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (x: Exception) { throw VideoFrameProcessingException(x, presentationTimeUs) }
    }
    override fun release() { super.release(); try { prog.delete() } catch (_: Exception) {} }
}

class Fft(val n: Int) {
    private val cosT = FloatArray(n / 2) { cos(2 * PI * it / n).toFloat() }
    private val sinT = FloatArray(n / 2) { -sin(2 * PI * it / n).toFloat() }
    private val rev = IntArray(n)
    init { val bits = Integer.numberOfTrailingZeros(n); for (i in 0 until n) { var x = i; var r = 0; for (b in 0 until bits) { r = (r shl 1) or (x and 1); x = x shr 1 }; rev[i] = r } }
    fun run(re: FloatArray, im: FloatArray, inverse: Boolean) {
        for (i in 0 until n) { val j = rev[i]; if (j > i) { var t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t } }
        var len = 2
        while (len <= n) {
            val half = len / 2; val step = n / len; var i = 0
            while (i < n) {
                for (j in 0 until half) {
                    val wr = cosT[j * step]; val wi = if (inverse) -sinT[j * step] else sinT[j * step]
                    val a = i + j; val b = a + half
                    val xr = re[b] * wr - im[b] * wi; val xi = re[b] * wi + im[b] * wr
                    re[b] = re[a] - xr; im[b] = im[a] - xi; re[a] += xr; im[a] += xi
                }
                i += len
            }
            len *= 2
        }
        if (inverse) for (i in 0 until n) { re[i] /= n; im[i] /= n }
    }
}

/** Audio clean-up: streaming spectral noise reduction (level 1-3) + volume gain. level 0 = gain only. */
class AudioFx(private val level: Int, private val gain: Float) : BaseAudioProcessor() {
    private val N = 1024; private val H = 512
    private val alpha = floatArrayOf(0f, 1.2f, 1.8f, 2.5f)[level]; private val floorG = floatArrayOf(1f, 0.35f, 0.2f, 0.1f)[level]
    private val fft = Fft(N); private val win = FloatArray(N) { sqrt(0.5 - 0.5 * cos(2 * PI * (it + 0.5) / N)).toFloat() }
    private var ch = 2; private var ready = false
    private var hop = Array(0) { FloatArray(0) }; private var frame = Array(0) { FloatArray(0) }; private var ola = Array(0) { FloatArray(0) }
    private var noise = Array(0) { FloatArray(0) }; private var prevG = Array(0) { FloatArray(0) }; private var inited = BooleanArray(0)
    private val re = FloatArray(N); private val im = FloatArray(N); private val mag = FloatArray(N / 2 + 1); private val gr = FloatArray(N / 2 + 1); private val gs = FloatArray(N / 2 + 1)
    private var fill = 0; private var received = 0L; private var emitted = 0L; private var skip = N - H

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        ch = inputAudioFormat.channelCount
        hop = Array(ch) { FloatArray(H) }; frame = Array(ch) { FloatArray(N) }; ola = Array(ch) { FloatArray(N) }
        noise = Array(ch) { FloatArray(N / 2 + 1) }; prevG = Array(ch) { FloatArray(N / 2 + 1) { 1f } }; inited = BooleanArray(ch)
        ready = true; resetState()
        return inputAudioFormat
    }
    private fun resetState() {
        if (!ready) return
        fill = 0; received = 0; emitted = 0; skip = N - H
        for (c in 0 until ch) { frame[c].fill(0f); ola[c].fill(0f); hop[c].fill(0f); prevG[c].fill(1f); inited[c] = false }
    }
    override fun onFlush() { resetState() }
    override fun onReset() { resetState() }

    private fun s16(v: Float): Short = (v * gain * 32767f).coerceIn(-32768f, 32767f).toInt().toShort()

    override fun queueInput(inputBuffer: ByteBuffer) {
        val frames = inputBuffer.remaining() / (2 * ch); if (frames == 0) return
        if (level == 0) {
            val out = replaceOutputBuffer(frames * 2 * ch)
            for (i in 0 until frames * ch) out.putShort(s16(inputBuffer.getShort() / 32768f))
            out.flip(); return
        }
        val hops = (fill + frames) / H
        val out = replaceOutputBuffer(hops * H * ch * 2)
        for (f in 0 until frames) {
            for (c in 0 until ch) hop[c][fill] = inputBuffer.getShort() / 32768f
            fill++; received++
            if (fill == H) { process(out); fill = 0 }
        }
        out.flip()
    }

    override fun onQueueEndOfStream() {
        if (level == 0) return
        val hopsN = ((received - emitted + skip + H - 1) / H).toInt().coerceAtLeast(0)
        val out = replaceOutputBuffer(hopsN * H * ch * 2)
        repeat(hopsN) { for (c in 0 until ch) for (i in fill until H) hop[c][i] = 0f; fill = 0; process(out) }
        out.flip()
    }

    private fun process(out: ByteBuffer) {
        val res = Array(ch) { step(it) }
        for (i in 0 until H) {
            if (skip > 0) { skip--; continue }
            if (emitted >= received) break
            for (c in 0 until ch) out.putShort(s16(res[c][i]))
            emitted++
        }
    }

    private fun step(c: Int): FloatArray {
        val fr = frame[c]; System.arraycopy(fr, H, fr, 0, N - H); System.arraycopy(hop[c], 0, fr, N - H, H)
        for (i in 0 until N) { re[i] = fr[i] * win[i]; im[i] = 0f }
        fft.run(re, im, false)
        val nb = noise[c]; val pg = prevG[c]; val half = N / 2
        for (k in 0..half) mag[k] = sqrt(re[k] * re[k] + im[k] * im[k]) + 1e-9f
        if (!inited[c]) { System.arraycopy(mag, 0, nb, 0, half + 1); inited[c] = true }
        for (k in 0..half) {
            nb[k] = if (mag[k] < nb[k]) nb[k] * 0.8f + mag[k] * 0.2f else nb[k] * 1.0015f
            gr[k] = max(floorG, 1f - alpha * nb[k] / mag[k])
        }
        for (k in 0..half) {
            val s = 0.25f * gr[max(k - 1, 0)] + 0.5f * gr[k] + 0.25f * gr[min(k + 1, half)]
            val g = 0.5f * pg[k] + 0.5f * s; pg[k] = g; gs[k] = g
        }
        for (k in 0..half) { re[k] *= gs[k]; im[k] *= gs[k]; if (k in 1 until half) { re[N - k] *= gs[k]; im[N - k] *= gs[k] } }
        fft.run(re, im, true)
        val o = ola[c]; for (i in 0 until N) o[i] += re[i] * win[i]
        val res = FloatArray(H); System.arraycopy(o, 0, res, 0, H)
        System.arraycopy(o, H, o, 0, N - H); for (i in N - H until N) o[i] = 0f
        return res
    }
}
