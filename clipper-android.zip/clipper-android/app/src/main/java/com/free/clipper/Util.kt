package com.free.clipper

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

data class Cap(val s: Long, val e: Long, val t: String)

/** RMS loudness for every 50 ms of audio */
fun audioRms(ctx: Context, u: Uri, dur: Long, prog: (Int) -> Unit): DoubleArray {
    val ex = MediaExtractor(); ex.setDataSource(ctx, u, null)
    val ti = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
    ex.selectTrack(ti); val f = ex.getTrackFormat(ti)
    val dec = MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME)!!); dec.configure(f, null, null, 0); dec.start()
    val info = MediaCodec.BufferInfo(); val rms = ArrayList<Double>()
    var inDone = false; var outDone = false; var sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); var ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
    var sum = 0.0; var n = 0; var lastP = -1
    while (!outDone) {
        if (!inDone) {
            val i = dec.dequeueInputBuffer(5000)
            if (i >= 0) {
                val sz = ex.readSampleData(dec.getInputBuffer(i)!!, 0)
                if (sz < 0) { dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                else {
                    val t = ex.sampleTime; dec.queueInputBuffer(i, 0, sz, t, 0); ex.advance()
                    if (dur > 0) { val pc = (t / 1000 * 100 / dur).toInt().coerceIn(0, 100); if (pc != lastP) { lastP = pc; prog(pc) } }
                }
            }
        }
        val o = dec.dequeueOutputBuffer(info, 5000)
        if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { sr = dec.outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = dec.outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) }
        else if (o >= 0) {
            val sb = dec.getOutputBuffer(o)!!.order(ByteOrder.nativeOrder()).asShortBuffer(); val per = (sr * ch * 0.05).toInt()
            while (sb.hasRemaining()) { val s = sb.get().toDouble(); sum += s * s; n++; if (n >= per) { rms.add(sqrt(sum / n) / 32768.0); sum = 0.0; n = 0 } }
            dec.releaseOutputBuffer(o, false); if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
        }
    }
    dec.stop(); dec.release(); ex.release()
    return rms.toDoubleArray()
}

/** Copies the audio track between startMs..endMs into a small .m4a (no re-encode). Returns real start offset in ms. */
fun extractAudio(ctx: Context, u: Uri, startMs: Long, endMs: Long, out: File): Long {
    val ex = MediaExtractor(); ex.setDataSource(ctx, u, null)
    val ti = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
    ex.selectTrack(ti); val fmt = ex.getTrackFormat(ti)
    out.delete(); val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    val tr = mux.addTrack(fmt); mux.start()
    ex.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
    val buf = ByteBuffer.allocate(1 shl 20); val bi = MediaCodec.BufferInfo(); var base = -1L
    while (true) {
        val sz = ex.readSampleData(buf, 0); if (sz < 0) break
        val t = ex.sampleTime; if (t > endMs * 1000) break
        if (base < 0) base = t
        bi.set(0, sz, t - base, ex.sampleFlags and 1)
        mux.writeSampleData(tr, buf, bi); ex.advance()
    }
    mux.stop(); mux.release(); ex.release()
    return maxOf(0L, base) / 1000
}

/** Groq Whisper (whisper-large-v3-turbo), OpenAI-compatible endpoint. lang = ISO code or null for auto-detect. */
fun whisper(key: String, f: File, lang: String?): JSONObject {
    val bd = "----clip" + System.nanoTime()
    val c = URL("https://api.groq.com/openai/v1/audio/transcriptions").openConnection() as HttpURLConnection
    c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 30000; c.readTimeout = 180000
    c.setRequestProperty("Authorization", "Bearer $key"); c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$bd")
    c.setChunkedStreamingMode(0)
    DataOutputStream(c.outputStream).use { o ->
        fun field(n: String, v: String) { o.writeBytes("--$bd\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n") }
        field("model", "whisper-large-v3-turbo"); field("response_format", "verbose_json")
        field("timestamp_granularities[]", "word"); field("timestamp_granularities[]", "segment")
        if (lang != null) field("language", lang)
        o.writeBytes("--$bd\r\nContent-Disposition: form-data; name=\"file\"; filename=\"a.m4a\"\r\nContent-Type: audio/mp4\r\n\r\n")
        f.inputStream().use { it.copyTo(o) }
        o.writeBytes("\r\n--$bd--\r\n")
    }
    val code = c.responseCode
    val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
    if (code !in 200..299) throw Exception("HTTP $code ${txt.take(160)}")
    return JSONObject(txt)
}

fun wrapCap(t: String): String {
    if (t.length <= 18) return t
    val mid = t.length / 2; val i1 = t.lastIndexOf(' ', mid); val i2 = t.indexOf(' ', mid)
    val i = if (i1 < 0) i2 else if (i2 < 0) i1 else if (mid - i1 <= i2 - mid) i1 else i2
    return if (i < 0) t else t.substring(0, i) + "\n" + t.substring(i + 1)
}

/** Short 1-4 word subtitle groups (Shorts style) from word timestamps; falls back to segments. */
fun toCaps(j: JSONObject, off: Long): List<Cap> {
    val out = ArrayList<Cap>(); val words = j.optJSONArray("words")
    if (words != null && words.length() > 0) {
        var sb = StringBuilder(); var gs = 0.0; var ge = 0.0; var n = 0
        fun flush() { val t = sb.toString().trim(); if (t.isNotEmpty()) out.add(Cap(off + (gs * 1000).toLong(), off + (ge * 1000).toLong(), wrapCap(t))); sb = StringBuilder(); n = 0 }
        for (i in 0 until words.length()) {
            val w = words.getJSONObject(i); val ws = w.getDouble("start"); val we = w.getDouble("end"); val tx = w.getString("word").trim()
            if (n > 0 && (ws - ge > 0.6 || we - gs > 2.2 || n >= 4)) flush()
            if (n == 0) gs = ws
            val cjk = tx.isNotEmpty() && tx[0].code.let { it in 0x3000..0x9FFF || it in 0x0E00..0x0E7F }
            if (n > 0 && !cjk) sb.append(' '); sb.append(tx); ge = we; n++
        }
        flush()
    } else {
        val seg = j.optJSONArray("segments")
        if (seg != null) for (i in 0 until seg.length()) { val s = seg.getJSONObject(i); out.add(Cap(off + (s.getDouble("start") * 1000).toLong(), off + (s.getDouble("end") * 1000).toLong(), wrapCap(s.getString("text").trim()))) }
    }
    return out
}
