package com.free.clipper

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Audio-only moment finder. r = RMS loudness per 50 ms (20 values per second). */
object Moments {
    val TYPES = listOf("Best", "Funny", "Crazy", "Serious")
    val ICONS = mapOf("Best" to "⭐", "Funny" to "😂", "Crazy" to "🤯", "Serious" to "🎯")
    class Hit(val type: String, val rank: Int, val startS: Int, val endS: Int, val score: Double)

    private fun smooth(a: DoubleArray, rad: Int): DoubleArray {
        val p = DoubleArray(a.size + 1); for (i in a.indices) p[i + 1] = p[i] + a[i]
        return DoubleArray(a.size) { s -> val lo = maxOf(0, s - rad); val hi = minOf(a.size - 1, s + rad); (p[hi + 1] - p[lo]) / (hi - lo + 1) }
    }

    fun find(r: DoubleArray, types: List<String>, len: Int, k: Int): List<Hit> {
        val sec = r.size / 20; if (sec < len + 2) return emptyList()
        val mean = DoubleArray(sec); val peak = DoubleArray(sec); val cv = DoubleArray(sec); val dens = DoubleArray(sec); val burst = DoubleArray(sec)
        for (s in 0 until sec) {
            var sum = 0.0; var mx = 0.0; var act = 0
            for (i in 0 until 20) { val v = r[s * 20 + i]; sum += v; if (v > mx) mx = v; if (v > 0.01) act++ }
            val m = sum / 20; var sq = 0.0; var b = 0
            for (i in 0 until 20) {
                val v = r[s * 20 + i]; sq += (v - m) * (v - m)
                if (i > 0 && i < 19 && v > r[s * 20 + i - 1] && v >= r[s * 20 + i + 1] && v > 1.3 * m && v > 0.02) b++
            }
            mean[s] = m; peak[s] = mx; cv[s] = if (m > 1e-4) sqrt(sq / 20) / m else 0.0; dens[s] = act / 20.0; burst[s] = b.toDouble()
        }
        val base = smooth(mean, 60); val pbase = smooth(peak, 60); val bs = smooth(burst, 2)
        val p90 = mean.sortedArray()[(sec * 0.9).toInt().coerceAtMost(sec - 1)]
        val p99 = peak.sortedArray()[(sec * 0.99).toInt().coerceAtMost(sec - 1)]
        val out = ArrayList<Hit>(); val used = ArrayList<IntRange>()
        for (type in types) {
            val raw = DoubleArray(sec) { s ->
                val m = mean[s]
                when (type) {
                    "Best" -> if (m < 0.01) 0.0 else 0.6 * m / max(base[s], 0.005) + 0.4 * peak[s] / max(pbase[s], 0.01)
                    "Crazy" -> if (m < 0.01) 0.0 else 0.5 * m / max(p90, 0.01) + 0.5 * peak[s] / max(p99, 0.02)
                    "Funny" -> if (m < 0.015) 0.0 else min(1.5, bs[s] / 3.0) * min(2.0, m / max(base[s], 0.005))
                    else -> if (m < 0.015) 0.0 else dens[s] * (1.0 / (1.0 + cv[s])) * (1.0 - min(1.0, abs(m / max(base[s], 0.005) - 1.0)))
                }
            }
            val sc = smooth(raw, if (type == "Serious") len / 2 else 2)
            var rank = 0
            for (s in sc.indices.sortedByDescending { sc[it] }) {
                if (rank >= k || sc[s] <= 0.0) break
                var st = if (type == "Serious") s - len / 2 else s - (len * 0.6).toInt()
                st = st.coerceIn(0, sec - len); val en = st + len
                if (used.any { u -> max(0, min(u.last + 1, en) - max(u.first, st)) > len / 2 }) continue
                rank++; used.add(st until en); out.add(Hit(type, rank, st, en, sc[s]))
            }
        }
        return out
    }
}
