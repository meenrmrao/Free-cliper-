package com.free.clipper

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

/** Vector-style icons drawn with Canvas on a 24x24 grid (no resource files needed). */
class IconView(c: Context, var kind: String, var color: Int = Color.WHITE) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height) / 24f
        cv.save(); cv.translate((width - 24 * s) / 2, (height - 24 * s) / 2); cv.scale(s, s)
        p.color = color; p.strokeWidth = 2f; p.style = Paint.Style.STROKE; p.pathEffect = null
        fun ln(a: Float, b: Float, c: Float, d: Float) = cv.drawLine(a, b, c, d, p)
        fun fillPath(vararg pt: Float) { val pa = Path(); pa.moveTo(pt[0], pt[1]); var i = 2; while (i < pt.size) { pa.lineTo(pt[i], pt[i + 1]); i += 2 }; pa.close(); p.style = Paint.Style.FILL; cv.drawPath(pa, p); p.style = Paint.Style.STROKE }
        fun linePath(vararg pt: Float) { val pa = Path(); pa.moveTo(pt[0], pt[1]); var i = 2; while (i < pt.size) { pa.lineTo(pt[i], pt[i + 1]); i += 2 }; cv.drawPath(pa, p) }
        when (kind) {
            "play" -> fillPath(8f, 5f, 19f, 12f, 8f, 19f)
            "pause" -> { p.style = Paint.Style.FILL; cv.drawRoundRect(6f, 5f, 10f, 19f, 1.5f, 1.5f, p); cv.drawRoundRect(14f, 5f, 18f, 19f, 1.5f, 1.5f, p) }
            "scissors" -> { cv.drawCircle(7f, 17f, 3f, p); cv.drawCircle(17f, 17f, 3f, p); ln(8.5f, 14.5f, 18f, 4f); ln(15.5f, 14.5f, 6f, 4f) }
            "film" -> { cv.drawRoundRect(4f, 5f, 20f, 19f, 2f, 2f, p); ln(9f, 5f, 9f, 19f); ln(15f, 5f, 15f, 19f); ln(4f, 10f, 9f, 10f); ln(4f, 14f, 9f, 14f); ln(15f, 10f, 20f, 10f); ln(15f, 14f, 20f, 14f) }
            "sparkle" -> fillPath(12f, 2.5f, 14.2f, 9.8f, 21.5f, 12f, 14.2f, 14.2f, 12f, 21.5f, 9.8f, 14.2f, 2.5f, 12f, 9.8f, 9.8f)
            "chat" -> { cv.drawRoundRect(3.5f, 5f, 20.5f, 16f, 3f, 3f, p); linePath(8f, 16f, 8f, 20f, 12.5f, 16f); ln(8f, 9.5f, 16f, 9.5f); ln(8f, 12.5f, 13f, 12.5f) }
            "layers" -> { linePath(12f, 3.5f, 21f, 8.5f, 12f, 13.5f, 3f, 8.5f, 12f, 3.5f); linePath(3f, 12.5f, 12f, 17.5f, 21f, 12.5f); linePath(3f, 16.5f, 12f, 21.5f, 21f, 16.5f) }
            "half" -> { cv.drawCircle(12f, 12f, 8.5f, p); p.style = Paint.Style.FILL; cv.drawArc(RectF(3.5f, 3.5f, 20.5f, 20.5f), 90f, 180f, true, p) }
            "wave" -> { val h = floatArrayOf(5f, 11f, 17f, 9f, 13f, 6f); for (i in h.indices) { val x = 3.5f + i * 3.4f; ln(x, 12f - h[i] / 2, x, 12f + h[i] / 2) } }
            "speaker" -> { fillPath(4f, 9f, 8f, 9f, 13f, 5f, 13f, 19f, 8f, 15f, 4f, 15f); cv.drawArc(RectF(10f, 8f, 18f, 16f), -55f, 110f, false, p); cv.drawArc(RectF(8f, 5f, 21f, 19f), -55f, 110f, false, p) }
            "gauge" -> { cv.drawArc(RectF(3f, 5f, 21f, 23f), 180f, 180f, false, p); ln(12f, 14f, 17f, 9f); cv.drawCircle(12f, 14f, 1.3f, p) }
            "export" -> { ln(12f, 15f, 12f, 4f); linePath(8f, 8f, 12f, 4f, 16f, 8f); linePath(5f, 14f, 5f, 20f, 19f, 20f, 19f, 14f) }
            "import" -> { ln(12f, 4f, 12f, 15f); linePath(8f, 11f, 12f, 15f, 16f, 11f); linePath(5f, 14f, 5f, 20f, 19f, 20f, 19f, 14f) }
            "wand" -> { ln(4.5f, 19.5f, 15f, 9f); ln(17f, 3.5f, 17f, 8.5f); ln(14.5f, 6f, 19.5f, 6f); ln(19f, 11f, 19f, 14f); ln(17.5f, 12.5f, 20.5f, 12.5f) }
            "trash" -> { cv.drawRoundRect(7f, 8f, 17f, 20f, 2f, 2f, p); ln(5f, 6f, 19f, 6f); linePath(10f, 6f, 10f, 4f, 14f, 4f, 14f, 6f) }
            "plus" -> { ln(12f, 5f, 12f, 19f); ln(5f, 12f, 19f, 12f) }
            "back" -> linePath(15f, 5f, 8f, 12f, 15f, 19f)
            "next" -> linePath(9f, 5f, 16f, 12f, 9f, 19f)
            "split" -> { cv.drawRoundRect(3.5f, 6f, 10.5f, 18f, 2f, 2f, p); cv.drawRoundRect(13.5f, 6f, 20.5f, 18f, 2f, 2f, p) }
            "pin" -> { fillPath(6.5f, 3.5f, 17.5f, 3.5f, 12f, 12f); ln(12f, 12f, 12f, 20.5f) }
            "area" -> { p.pathEffect = DashPathEffect(floatArrayOf(3f, 2.5f), 0f); cv.drawRoundRect(4f, 5f, 20f, 19f, 2f, 2f, p) }
            "check" -> linePath(5f, 12.5f, 10f, 17.5f, 19f, 7f)
            "mic" -> { cv.drawRoundRect(9f, 3f, 15f, 14f, 3f, 3f, p); cv.drawArc(RectF(5.5f, 7f, 18.5f, 19f), 0f, 180f, false, p); ln(12f, 19f, 12f, 22f) }
        }
        cv.restore()
    }
}

/** Row of colour swatches */
class SwatchRow(c: Context, val cols: List<Int>, var sel: Int, val cb: (Int) -> Unit) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), (40 * resources.displayMetrics.density).toInt()) }
    override fun onDraw(c: Canvas) {
        val cell = width.toFloat() / cols.size; val r = minOf(cell, height.toFloat()) / 2 - 6
        cols.forEachIndexed { i, col ->
            val cx = cell * i + cell / 2; val cy = height / 2f
            p.style = Paint.Style.FILL; p.color = col; c.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0xFF4A5160.toInt(); c.drawCircle(cx, cy, r, p)
            if (i == sel) { p.strokeWidth = 5f; p.color = Color.WHITE; c.drawCircle(cx, cy, r + 4, p) }
        }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_UP) {
            val i = (e.x / (width.toFloat() / cols.size)).toInt().coerceIn(0, cols.size - 1)
            if (e.action == MotionEvent.ACTION_UP) { sel = i; cb(i); invalidate() }
        }
        return true
    }
}

/** Loudness waveform + clip markers + playhead; tap to seek */
class WaveView(c: Context) : View(c) {
    var rms: DoubleArray? = null; var dur = 0L; var pos = 0L; var clips: List<Clip> = emptyList(); var onTap: ((Long) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var bars = FloatArray(0); private var bw = -1
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), (72 * resources.displayMetrics.density).toInt()) }
    private fun build() {
        val r = rms ?: return; val n = (width / 4).coerceAtLeast(1); bars = FloatArray(n); val per = maxOf(1, r.size / n)
        var mx = 1e-6f
        for (i in 0 until n) { var m = 0.0; for (k in i * per until minOf(r.size, (i + 1) * per)) if (r[k] > m) m = r[k]; bars[i] = m.toFloat(); if (bars[i] > mx) mx = bars[i] }
        for (i in 0 until n) bars[i] = Math.pow((bars[i] / mx).toDouble(), 0.6).toFloat()
        bw = width
    }
    override fun onDraw(c: Canvas) {
        p.style = Paint.Style.FILL; p.color = 0xFF181B21.toInt(); c.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 18f, 18f, p)
        if (rms == null || dur <= 0) { p.color = 0xFF9AA0AC.toInt(); p.textSize = 34f; p.textAlign = Paint.Align.CENTER; c.drawText("Tap to load waveform", width / 2f, height / 2f + 12, p); return }
        if (bw != width) build()
        clips.forEach { cl -> p.color = if (cl.on) 0x556C5CE7 else 0x22FFFFFF; c.drawRect(cl.s * width.toFloat() / dur, 0f, cl.e * width.toFloat() / dur, height.toFloat(), p) }
        p.color = 0xFF8E7DFF.toInt(); val mid = height / 2f
        for (i in bars.indices) { val h = bars[i] * (height * 0.42f); c.drawRect(i * 4f, mid - h, i * 4f + 2.5f, mid + h + 1, p) }
        p.color = Color.WHITE; val x = pos * width.toFloat() / dur; c.drawRect(x - 1.5f, 0f, x + 1.5f, height.toFloat(), p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent.requestDisallowInterceptTouchEvent(true)
        if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) onTap?.invoke((e.x / width * maxOf(dur, 1)).toLong().coerceIn(0, maxOf(dur, 1)))
        return true
    }
}
