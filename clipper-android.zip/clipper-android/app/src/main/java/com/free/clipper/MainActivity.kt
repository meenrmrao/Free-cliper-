package com.free.clipper

import android.content.*
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.text.InputType
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.*
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.*
import androidx.media3.ui.AspectRatioFrameLayout
import com.google.common.collect.ImmutableList
import java.io.File

data class Clip(val uri: Uri, val s: Long, val e: Long, val tag: String = "", val auto: Boolean = false, var on: Boolean = true)
class TLayer(val text: String, val color: Int, val size: Float, val x: Float, val y: Float)
class ILayer(val bmp: Bitmap, val frac: Float, val x: Float, val y: Float)

class MainActivity : AppCompatActivity() {
    val BG = 0xFF0B0D11.toInt(); val SF = 0xFF161A21.toInt(); val SF2 = 0xFF242A35.toInt(); val AC = 0xFF7C5CFF.toInt(); val AC2 = 0xFF4C8DFF.toInt(); val TX = 0xFFF1F3F6.toInt(); val MU = 0xFF98A0AE.toInt()
    lateinit var player: ExoPlayer; lateinit var vtex: TextureView; lateinit var arf: AspectRatioFrameLayout; lateinit var mark: MarkView
    lateinit var prev: PreviewView; lateinit var prev1: PreviewView; lateinit var pf: FrameLayout; lateinit var ctl: LinearLayout
    lateinit var p1: ScrollView; lateinit var p2: ScrollView; lateinit var p3: LinearLayout
    lateinit var ctlPlay: IconView; lateinit var ctlSeek: SeekBar; lateinit var ctlTime: TextView; lateinit var wave: WaveView
    lateinit var areaInfo: TextView; lateinit var info: TextView; lateinit var clipsBox: LinearLayout; lateinit var layersBox: LinearLayout
    lateinit var capInfo: TextView; lateinit var expInfo: TextView; lateinit var status: TextView; lateinit var expBar: ProgressBar; lateinit var capPrev: ImageView
    lateinit var dlgText: TextView; var dlg: AlertDialog? = null
    var rbs = listOf<RadioButton>(); val need = listOf(1, 2, 3, 2); val layouts = Layout.values()
    var panels = listOf<View>(); var tiles = listOf<View>()
    var cur: Uri? = null; var ms = 0L; var me = 0L; var rms: DoubleArray? = null; var step = 1; var dirty = true; var seeking = false
    val clips = ArrayList<Clip>(); val caps = ArrayList<Cap>(); val tls = ArrayList<TLayer>(); val ils = ArrayList<ILayer>()
    var chosen = Layout.SPLIT; var split = 0.4f; var swap = false
    val ARS = listOf(9f / 16, 4f / 5, 1f, 16f / 9); var arI = 0
    val msel = BooleanArray(4); var mLen = 30; var mK = 5
    // subtitles style
    var capFont = 0; var customTf: Typeface? = null; var capSize = 7; var capMode = 2; var capPal = 0; var capCol = 0; var capHi = 1; var capOutW = 5; var capOutCol = 11
    var capShadow = true; var capBgMode = 0; var capBgCol = 11; var capBgAlpha = 70; var capUpper = false; var capPos = 2; var capOn = true
    // look + audio
    var grade = Grade(); var warm = 0f; var preset = 0; var dnA = 0; var volI = 1; var normOn = false; var normGain = 1f; var mute = false
    val SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f); var speedI = 2
    var resI = 1; var fpsI = 1; var brI = 0; var mergeI = 0; var custBr = 0f
    val BRS = listOf(0f, 1f, 2f, 3f, 4f, 5f, 6f, 8f, 10f, 12f, 15f, 20f, 25f, 30f, 40f, 50f)
    var jobs = listOf<List<Clip>>(); var jobI = 0; var okN = 0; var failN = 0; var exporting = false; var lastErr = ""
    val h = Handler(Looper.getMainLooper()); val prefs by lazy { getSharedPreferences("clipper", 0) }
    var pendingImg: ((Bitmap) -> Unit)? = null
    var spA: Spinner? = null; var spBr: Spinner? = null; var spRes: Spinner? = null; var spFps: Spinner? = null
    val sliders = ArrayList<Pair<SeekBar, () -> Int>>()

    // ---------- UI helpers ----------
    fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    fun rr(c: Int, r: Int = 14) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    fun grad(r: Int = 14) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(AC, AC2)).apply { cornerRadius = dp(r).toFloat() }
    fun tv(t: String, sz: Float = 14f, c: Int = TX) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }
    fun icon(k: String, sz: Int = 20, c: Int = TX) = IconView(this, k, c).apply { layoutParams = LinearLayout.LayoutParams(dp(sz), dp(sz)) }
    fun head(t: String) = tv(t, 17f).apply { setTypeface(null, Typeface.BOLD); setPadding(0, dp(6), 0, dp(6)) }
    fun lbl(t: String) = tv(t, 12f, MU).apply { setPadding(dp(2), dp(6), 0, dp(2)) }
    fun btn(k: String?, t: String, filled: Boolean = false, f: () -> Unit): LinearLayout {
        val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; background = if (filled) grad(12) else rr(SF2, 12); setPadding(dp(14), dp(10), dp(14), dp(10)) }
        if (k != null) { l.addView(icon(k, 18)); l.addView(View(this), dp(6), 1) }
        l.addView(tv(t, 13f).apply { setTypeface(null, Typeface.BOLD) })
        l.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }; l.setOnClickListener { f() }; return l
    }
    fun sp(items: List<String>, init: Int, cb: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items); setSelection(init); background = rr(SF2, 10)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { cb(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }
    fun row(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; v.forEach { addView(it) } }
    fun col(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; v.forEach { addView(it) } }
    fun card(t: String, k: String, vararg v: View) = col(row(icon(k, 20, AC2), tv("  $t", 16f).apply { setTypeface(null, Typeface.BOLD) }), *v).apply {
        background = rr(SF, 18); setPadding(dp(14), dp(12), dp(14), dp(12)); layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(10), dp(6), dp(10), dp(6)) } }
    fun pnl(vararg v: View) = ScrollView(this).apply { addView(col(*v).apply { setPadding(0, dp(4), 0, dp(12)) }); setBackgroundColor(BG) }
    fun cbx(t: String, on: Boolean, cb: (Boolean) -> Unit) = CheckBox(this).apply { text = t; setTextColor(TX); isChecked = on; buttonTintList = ColorStateList.valueOf(AC); setOnCheckedChangeListener { _, v -> cb(v) } }
    fun edit(hint: String, def: String = "", num: Boolean = false) = EditText(this).apply {
        setText(def); this.hint = hint; setTextColor(TX); setHintTextColor(MU); background = rr(SF2, 10); setPadding(dp(12), dp(8), dp(12), dp(8)); textSize = 14f
        if (num) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED or InputType.TYPE_NUMBER_FLAG_DECIMAL
    }
    fun bar(max: Int, prog: Int, cb: (Int) -> Unit) = SeekBar(this).apply { this.max = max; progress = prog
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) cb(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
        }) }
    fun swatch(sel: Int, cb: (Int) -> Unit) = SwatchRow(this, Subs.COLS, sel, cb)
    fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    fun fmtT(ms: Long): String { val s = ms / 1000; return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s / 60 % 60, s % 60) else "%d:%02d".format(s / 60, s % 60) }
    fun showBusy(m: String) { dlgText = tv(m).apply { setPadding(dp(24), dp(24), dp(24), dp(24)) }; dlg = AlertDialog.Builder(this).setView(dlgText).setCancelable(false).create(); dlg!!.show() }
    fun busy(m: String) = runOnUiThread { if (dlg != null) dlgText.text = m }
    fun hideBusy() { dlg?.dismiss(); dlg = null }

    // ---------- Screens ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG; window.navigationBarColor = BG
        player = ExoPlayer.Builder(this).build()
        vtex = TextureView(this); player.setVideoTextureView(vtex)
        arf = AspectRatioFrameLayout(this).apply { resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT; addView(vtex, FrameLayout.LayoutParams(-1, -1)) }
        player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(v: VideoSize) { if (v.width > 0 && v.height > 0) { mark.vw = v.width; mark.vh = v.height; arf.setAspectRatio(v.width.toFloat() / v.height * v.pixelWidthHeightRatio); mark.invalidate(); dirty = true } }
            override fun onPlaybackStateChanged(s: Int) { if (s == Player.STATE_READY && me == 0L) { me = player.duration; wave.dur = me; upd() } }
        })
        mark = MarkView(this).apply { onChange = { dirty = true; syncPrev() } }
        pf = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); addView(arf, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER)); addView(mark); setOnClickListener { togglePlay() } }
        arf.setOnClickListener { togglePlay() }
        ctlPlay = IconView(this, "play").apply { layoutParams = LinearLayout.LayoutParams(dp(30), dp(30)); setOnClickListener { togglePlay() } }
        ctlSeek = SeekBar(this).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) { player.seekTo(p.toLong()); dirty = true } }
                override fun onStartTrackingTouch(s: SeekBar?) { seeking = true }; override fun onStopTrackingTouch(s: SeekBar?) { seeking = false }
            }) }
        ctlTime = tv("0:00 / 0:00", 12f, MU)
        ctl = row(ctlPlay, ctlSeek, ctlTime).apply { setBackgroundColor(SF); setPadding(dp(12), dp(4), dp(12), dp(4)) }
        areaInfo = tv("Areas marked: 0", 12f, MU)
        prev1 = PreviewView(this); prev = PreviewView(this)

        // Step 1
        val left = col(head("1 · Mark areas"), tv("Play or scrub to a frame, add areas (1 = facecam, 2 = gameplay). Drag a box to move, drag its dot to resize.", 12f, MU),
            btn("import", "Import video", true) { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "video/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 1) },
            row(btn("plus", "Add area") { addArea() }, btn("trash", "Delete") { delArea() }), areaInfo,
            btn("next", "Next", true) { if (mark.regs.isEmpty()) areaInfo.text = "Add at least one area first" else go(2) })
        left.layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        prev1.layoutParams = LinearLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.30).toInt())
        p1 = ScrollView(this).apply { addView(row(left, col(lbl("Live preview (final look)"), prev1).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 0.7f) }).apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }) }

        // Step 2
        val rg = RadioGroup(this)
        rbs = listOf("Single area (area 1 full)", "Split (area 1 top, area 2 bottom)", "3-part stack (areas 1, 2, 3)", "Picture-in-picture (area 1 over area 2)").mapIndexed { i, t ->
            RadioButton(this).apply { text = t; setTextColor(TX); id = View.generateViewId(); buttonTintList = ColorStateList.valueOf(AC); setOnClickListener { chosen = layouts[i]; refresh() } }.also { rg.addView(it) } }
        p2 = ScrollView(this).apply { addView(col(head("2 · Choose layout"), prev.apply { layoutParams = LinearLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.46).toInt()) }, rg,
            cbx("Swap order of areas", false) { swap = it; refresh() }, lbl("Size of first section"), bar(35, 15) { split = (25 + it) / 100f; refresh() },
            row(tv("Output  "), sp(listOf("9:16 Shorts / Reels", "4:5 Feed", "1:1 Square", "16:9 Wide"), 0) { arI = it; refresh() }),
            row(btn("back", "Back") { go(1) }, btn("next", "Next", true) { go(3) })).apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }) }

        p3 = col(buildEditor())
        val root = col(pf, ctl, p1, p2, p3).apply { setBackgroundColor(BG) }
        p1.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f); p2.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f); p3.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        setContentView(root); go(1); h.post(tick)
    }

    val tick = object : Runnable { override fun run() {
        try {
            val dur = player.duration; val pos = player.currentPosition
            if (dur > 0) { if (ctlSeek.max != dur.toInt()) ctlSeek.max = dur.toInt(); if (!seeking) ctlSeek.progress = pos.toInt() }
            ctlTime.text = "${fmtT(pos)} / ${fmtT(maxOf(dur, 0))}"
            val k = if (player.isPlaying) "pause" else "play"; if (ctlPlay.kind != k) { ctlPlay.kind = k; ctlPlay.invalidate() }
            if (step == 1 && (player.isPlaying || dirty)) { grab(); dirty = false }
            if (step == 3) { wave.pos = pos; wave.invalidate() }
        } catch (_: Exception) {}
        h.postDelayed(this, 200)
    } }
    fun togglePlay() { if (cur == null) return; if (player.isPlaying) player.pause() else player.play() }
    fun grab() {
        try {
            if (!vtex.isAvailable || mark.vw <= 0) return
            val w = 480; val bm = vtex.getBitmap(w, (w.toFloat() * mark.vh / mark.vw).toInt().coerceAtLeast(2)) ?: return
            prev1.bmp = bm; prev.bmp = bm; syncPrev()
        } catch (_: Exception) {}
    }
    fun syncPrev() {
        val regs = mark.regs.map { RectF(it) }; val lay = if (step == 1) (if (regs.size >= 2) Layout.SPLIT else Layout.SINGLE) else chosen
        prev1.regs = regs; prev1.lay = lay; prev1.split = split; prev1.swap = swap; prev1.ar = ARS[arI]; prev1.invalidate()
    }
    fun addArea() { if (cur == null) { areaInfo.text = "Import a video first"; return }; if (mark.regs.size < 3) { val k = mark.regs.size * 0.05f; mark.regs.add(RectF(0.2f + k, 0.2f + k, 0.5f + k, 0.5f + k)); mark.act = mark.regs.size - 1; mark.invalidate(); areaInfo.text = "Areas marked: ${mark.regs.size}"; dirty = true; syncPrev() } }
    fun delArea() { if (mark.act >= 0) { mark.regs.removeAt(mark.act); mark.act = mark.regs.size - 1; mark.invalidate(); areaInfo.text = "Areas marked: ${mark.regs.size}"; dirty = true; syncPrev() } }

    fun go(n: Int) {
        if (n == 2) { grab() }
        step = n; val H = resources.displayMetrics.heightPixels
        pf.visibility = if (n == 2) View.GONE else View.VISIBLE; ctl.visibility = pf.visibility; mark.visibility = if (n == 1) View.VISIBLE else View.GONE
        pf.layoutParams = LinearLayout.LayoutParams(-1, (H * (if (n == 1) 0.34 else 0.30)).toInt())
        p1.visibility = if (n == 1) View.VISIBLE else View.GONE; p2.visibility = if (n == 2) View.VISIBLE else View.GONE; p3.visibility = if (n == 3) View.VISIBLE else View.GONE
        if (n == 2) {
            player.pause()
            rbs.forEachIndexed { i, rb -> rb.isEnabled = mark.regs.size >= need[i] }
            if (mark.regs.size < need[layouts.indexOf(chosen)]) chosen = if (mark.regs.size >= 2) Layout.SPLIT else Layout.SINGLE
            rbs[layouts.indexOf(chosen)].isChecked = true; refresh()
        }
        if (n == 3) { upd(); rc(); wave.clips = clips }
        if (n == 1) { dirty = true; syncPrev() }
    }
    fun refresh() { prev.regs = mark.regs.map { RectF(it) }; prev.lay = chosen; prev.split = split; prev.swap = swap; prev.ar = ARS[arI]; prev.invalidate(); syncPrev() }
    override fun onBackPressed() { if (step > 1) go(step - 1) else super.onBackPressed() }

    // ---------- Editor ----------
    fun buildEditor(): View {
        info = tv("", 13f, MU); clipsBox = col(); layersBox = col(); capInfo = tv("No subtitles yet", 13f, MU); expInfo = tv("", 13f, MU); status = tv("", 13f, MU)
        expBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        wave = WaveView(this).apply { onTap = { t -> if (rms == null) analyze("Reading audio") {} else { player.seekTo(t) } } }

        // Trim
        val db = edit("dB", "-30", true); val minMs = edit("ms", "500", true)
        val trim = pnl(card("Timeline", "wave", wave, info,
            row(btn("pin", "Set start") { ms = player.currentPosition; upd() }, btn("pin", "Set end") { me = player.currentPosition; upd() }),
            row(btn("plus", "Add clip", true) { cur?.let { if (me > ms) { clips.add(Clip(it, ms, me)); rc() } } }, btn("scissors", "Split here") { splitHere() })),
            card("Cut silence", "mic", lbl("Keeps only the parts where someone is talking"), row(tv("dB "), db, tv("  min ms "), minMs), btn("scissors", "Cut silence") { silence(db.text.toString().toDoubleOrNull() ?: -30.0, minMs.text.toString().toLongOrNull() ?: 500) }))

        // Clips
        val cl = pnl(card("Clips", "film", row(btn("check", "All") { clips.forEach { it.on = true }; rc() }, btn(null, "None") { clips.forEach { it.on = false }; rc() }, btn("trash", "Clear auto") { clips.removeAll { it.auto }; rc() }), clipsBox))

        // Moments
        val mrow = Moments.TYPES.mapIndexed { i, t -> cbx("${Moments.ICONS[t]}  $t moments", false) { msel[i] = it } }
        val mom = pnl(card("Find moments", "sparkle", lbl("Tick one or more types. Analysis uses the video's audio: loudness, bursts, calm speech."), col(*mrow.toTypedArray()),
            row(tv("Length "), sp(listOf("15 sec", "30 sec", "45 sec", "60 sec"), 1) { mLen = listOf(15, 30, 45, 60)[it] }, tv("  Per type "), sp(listOf("Top 1", "Top 3", "Top 5", "Top 10"), 2) { mK = listOf(1, 3, 5, 10)[it] }),
            btn("sparkle", "Add moments", true) { addMoments() }))

        // Subtitles
        val key = edit("Groq API key (free)", prefs.getString("groq", "") ?: ""); key.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val langs = listOf("Auto-detect" to "", "Hinglish (Hindi in English letters)" to "hinglish", "Hindi (Devanagari)" to "hi", "English" to "en", "Urdu" to "ur", "Bengali" to "bn", "Tamil" to "ta", "Telugu" to "te", "Marathi" to "mr", "Gujarati" to "gu", "Punjabi" to "pa", "Spanish" to "es", "Portuguese" to "pt", "Arabic" to "ar", "Indonesian" to "id", "Russian" to "ru", "Turkish" to "tr", "French" to "fr", "German" to "de", "Japanese" to "ja", "Korean" to "ko")
        var li = 1; var whole = 0
        capPrev = ImageView(this).apply { setBackgroundColor(0xFF2D3340.toInt()); layoutParams = LinearLayout.LayoutParams(-1, dp(120)); scaleType = ImageView.ScaleType.FIT_CENTER }
        val subsGen = card("Auto subtitles", "chat", lbl("Whisper large-v3-turbo on Groq (free key: console.groq.com/keys). Needs internet."), key,
            row(sp(langs.map { it.first }, 1) { li = it }, sp(listOf("Selected clips", "Whole video"), 0) { whole = it }),
            btn("chat", "Generate subtitles", true) { val l = langs[li].second; genSubs(key.text.toString().trim(), if (l == "" || l == "hinglish") (if (l == "") null else "hi") else l, whole == 1, l == "hinglish") }, capInfo)
        val subsStyle = card("Subtitle style", "wand", capPrev,
            row(sp(Subs.FONT_NAMES, 0) { capFont = it; if (it == 8 && customTf == null) startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 3); capRefresh() },
                sp(listOf("Solid colour", "Multi-colour words", "Word highlight"), 2) { capMode = it; capRefresh() }),
            lbl("Size"), bar(10, 5) { capSize = 3 + it; capRefresh() },
            lbl("Text colour"), swatch(capCol) { capCol = it; capRefresh() },
            lbl("Highlight colour (word highlight)"), swatch(capHi) { capHi = it; capRefresh() },
            lbl("Colour palette (multi-colour)"), sp(Subs.PAL_NAMES, 0) { capPal = it; capRefresh() },
            lbl("Outline thickness"), bar(10, 5) { capOutW = it; capRefresh() }, lbl("Outline colour"), swatch(capOutCol) { capOutCol = it; capRefresh() },
            row(cbx("Shadow", true) { capShadow = it; capRefresh() }, cbx("UPPERCASE", false) { capUpper = it; capRefresh() }),
            lbl("Background box"), row(sp(listOf("None", "Box"), 0) { capBgMode = it; capRefresh() }, sp(listOf("Top", "Middle", "Lower", "Bottom"), 2) { capPos = it }),
            lbl("Box colour"), swatch(capBgCol) { capBgCol = it; capRefresh() }, lbl("Box opacity"), bar(100, 70) { capBgAlpha = it; capRefresh() },
            cbx("Burn subtitles into export", true) { capOn = it })
        val subs = pnl(subsGen, subsStyle)

        // Layers
        val txt = edit("Text or emoji (e.g. 🔥 FOLLOW)"); var tcol = 1; var tsz = 1; var tpos = 0; var tx = 1; var isz = 1; var ipos = 1
        val lay = pnl(card("Text layer (all clips)", "layers", txt, swatch(1) { tcol = it },
            row(sp(listOf("Small", "Medium", "Large"), 1) { tsz = it }, sp(listOf("Top", "Middle", "Bottom"), 0) { tpos = it }, sp(listOf("Left", "Center", "Right"), 1) { tx = it }),
            btn("plus", "Add text layer", true) { if (txt.text.isNotBlank()) { tls.add(TLayer(txt.text.toString(), Subs.COLS[tcol], listOf(0.05f, 0.07f, 0.1f)[tsz], listOf(-0.6f, 0f, 0.6f)[tx], listOf(0.8f, 0f, -0.8f)[tpos])); txt.setText(""); rl() } }),
            card("Image / logo layer", "layers", row(sp(listOf("Small", "Medium", "Large"), 1) { isz = it }, sp(listOf("Top-left", "Top-right", "Bottom-left", "Bottom-right", "Center"), 1) { ipos = it }),
                btn("import", "Choose image") { pendingImg = { bm -> ils.add(ILayer(bm, listOf(0.15f, 0.25f, 0.4f)[isz], listOf(-0.75f, 0.75f, -0.75f, 0.75f, 0f)[ipos], listOf(0.8f, 0.8f, -0.8f, -0.8f, 0f)[ipos])); rl() }
                    startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 2) }),
            card("Your layers", "layers", layersBox))

        // Color
        val presetRow = HorizontalScrollView(this).apply { addView(row(*PRESET_NAMES.mapIndexed { i, n -> btn(null, n, i == 0) { preset = i; grade = presetGrade(i); warm = 0f; syncSliders() } }.toTypedArray())) }
        fun sl(name: String, max: Int, get: () -> Int, set: (Int) -> Unit): View { val b = bar(max, get()) { set(it) }; sliders.add(Pair(b, { get() })); return col(lbl(name), b) }
        val color = pnl(card("Auto colour & clarity", "wand", lbl("One tap: fixes exposure, white balance, contrast, saturation and adds light clean-up + sharpening."),
            btn("wand", "Auto grade (best look)", true) { autoLook() }),
            card("Presets", "half", presetRow),
            card("Fine tune", "half",
                sl("Brightness", 100, { ((grade.bri + 0.25f) * 200).toInt() }) { grade.bri = it / 200f - 0.25f },
                sl("Contrast", 100, { ((grade.con - 0.6f) * 100).toInt() }) { grade.con = 0.6f + it / 100f },
                sl("Saturation", 100, { (grade.sat * 50).toInt() }) { grade.sat = it / 50f },
                sl("Warmth (cool ↔ warm)", 100, { ((warm + 0.15f) * 333).toInt() }) { warm = it / 333f - 0.15f },
                sl("Sharpness", 100, { (grade.shp * 100).toInt() }) { grade.shp = it / 100f },
                sl("Vignette", 100, { (grade.vig * 100).toInt() }) { grade.vig = it / 100f },
                btn(null, "Reset") { preset = 0; grade = Grade(); warm = 0f; syncSliders() }))

        // Clean (noise) + audio
        var dv = 0
        val clean = pnl(card("Remove noise", "wave", lbl("One tap: reduces background noise in the audio and grain in the video."),
            btn("wave", "Remove noise (audio + video)", true) { dnA = 2; grade.den = maxOf(grade.den, 0.5f); spA?.setSelection(dnA); dv = 2; toast("Noise removal ON (audio medium, video medium)") }),
            card("Audio", "speaker", lbl("Background noise reduction"), sp(listOf("Off", "Light", "Medium", "Strong"), 0) { dnA = it }.also { spA = it },
                lbl("Volume"), sp(listOf("50%", "100%", "150%", "200%"), 1) { volI = it },
                cbx("Normalize loudness (reads audio first)", false) { normOn = it; if (it) normalize() }, cbx("Mute original audio", false) { mute = it }),
            card("Video grain", "half", lbl("Removes noise / grain in dark or compressed video"), sp(listOf("Off", "Light", "Medium", "Strong"), 0) { dv = it; grade.den = listOf(0f, 0.25f, 0.5f, 0.8f)[it] }))

        // Speed
        val speed = pnl(card("Speed", "gauge", lbl("Changes speed of video and audio (pitch kept)"), sp(listOf("0.5x", "0.75x", "1x", "1.25x", "1.5x", "2x"), 2) { speedI = it }))

        // Export
        spRes = sp(listOf("Fast 480p", "Balanced 720p", "HD 1080p"), 1) { resI = it; est() }; spFps = sp(listOf("24 fps", "30 fps"), 1) { fpsI = it }
        spBr = sp(listOf("Auto") + BRS.drop(1).map { "${it.toInt()} Mbps" } + listOf("Custom"), 0) { brI = it; est() }
        val cb = edit("Custom Mbps (e.g. 7.5)", "", true); cb.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { custBr = s.toString().toFloatOrNull() ?: 0f; est() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}; override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {} })
        val exp = pnl(card("Quick presets", "export", row(btn(null, "Shorts / Reels") { preset3(2, 1, 7) }, btn(null, "Fast share") { preset3(1, 0, 3) }, btn(null, "Max quality") { preset3(2, 1, 9) })),
            card("Export", "export", expInfo, row(tv("Mode "), sp(listOf("Separate videos (fast, safe)", "Merge into one video"), 0) { mergeI = it }),
                row(tv("Quality "), spRes!!, tv("  FPS "), spFps!!), row(tv("Bitrate "), spBr!!), cb,
                btn("export", "Export selected clips", true) { startExport() }, expBar, status))

        panels = listOf(trim, cl, mom, subs, color, clean, speed, lay, exp)
        val box = FrameLayout(this).apply { panels.forEach { addView(it) } }
        val tools = listOf("scissors" to "Trim", "film" to "Clips", "sparkle" to "Moments", "chat" to "Subtitles", "half" to "Color", "wave" to "Clean", "gauge" to "Speed", "layers" to "Layers", "export" to "Export")
        tiles = tools.mapIndexed { i, t ->
            col(icon(t.first, 24).apply { (layoutParams as LinearLayout.LayoutParams).gravity = Gravity.CENTER_HORIZONTAL }, tv(t.second, 11f, MU).apply { gravity = Gravity.CENTER }).apply {
                setPadding(dp(14), dp(8), dp(14), dp(8)); setOnClickListener { showPanel(i) }; layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), dp(5), dp(3), dp(5)) } }
        }
        val tb = HorizontalScrollView(this).apply { setBackgroundColor(SF); addView(row(*tiles.toTypedArray())) }
        showPanel(0); capRefresh()
        return col(box.apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }, tb)
    }
    fun showPanel(i: Int) { panels.forEachIndexed { k, p -> p.visibility = if (k == i) View.VISIBLE else View.GONE }; tiles.forEachIndexed { k, t -> t.background = if (k == i) grad(14) else rr(SF2, 14) }; if (i == 8) est() }
    fun syncSliders() { sliders.forEach { (b, g) -> b.progress = g() } }
    fun preset3(res: Int, fps: Int, br: Int) { resI = res; fpsI = fps; brI = br; spRes?.setSelection(res); spFps?.setSelection(fps); spBr?.setSelection(br); est() }
    fun upd() { info.text = "Start ${fmtT(ms)}   ·   End ${fmtT(me)}" }

    // ---------- Subtitle style ----------
    fun capStyle(): CapStyle {
        val a = (capBgAlpha * 255 / 100); val bg = if (capBgMode == 1) ((a shl 24) or (Subs.COLS[capBgCol] and 0x00FFFFFF)) else 0
        return CapStyle(Subs.typeface(capFont, customTf), capSize / 100f, capMode, Subs.COLS[capCol], Subs.COLS[capHi], Subs.PALS[capPal], capOutW / 50f, Subs.COLS[capOutCol], capShadow, bg, capUpper, listOf(0.75f, 0f, -0.45f, -0.75f)[capPos])
    }
    fun capRefresh() {
        if (!::capPrev.isInitialized) return
        try {
            val st = capStyle(); val ws = listOf("Hello", "आप", "कैसे", "ho", "bhai").map { if (st.upper) it.uppercase() else it }
            val w = 640; val px = w * st.sizeFrac * 1.2f
            val bm = Subs.render(ws, Subs.colorsFor(ws.size, st.mode, 1, st.base, st.hi, st.pal), st.tf, px, (w * 0.9f).toInt(), st.outFrac * px, st.outCol, st.shadow, st.bg)
            capPrev.setImageBitmap(bm)
        } catch (_: Exception) {}
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        val u = d?.data ?: return
        if (rq == 2) {
            try { val o = BitmapFactory.Options().apply { inSampleSize = 2 }; contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o) }?.let { pendingImg?.invoke(it) } } catch (e: Exception) { toast("Image error: ${e.message}") }
            return
        }
        if (rq == 3) {
            try { val f = File(filesDir, "custom_font.ttf"); contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }; customTf = Typeface.createFromFile(f); capFont = 8; capRefresh(); toast("Font loaded") }
            catch (e: Exception) { toast("Could not load font: ${e.message}") }
            return
        }
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        cur = u; ms = 0; me = 0; rms = null; wave.rms = null; clips.clear(); caps.clear(); mark.regs.clear(); mark.act = -1; areaInfo.text = "Areas marked: 0"
        player.setMediaItem(MediaItem.fromUri(u)); player.prepare(); player.playWhenReady = true; mark.invalidate(); dirty = true
    }

    // ---------- Clips ----------
    fun splitHere() {
        val u = cur ?: return; val t = player.currentPosition
        var i = clips.indexOfFirst { it.uri == u && t > it.s && t < it.e }
        if (i < 0) { clips.add(Clip(u, 0, player.duration)); i = clips.size - 1 }
        val c = clips[i]; clips[i] = c.copy(e = t); clips.add(i + 1, c.copy(s = t, tag = "")); rc()
    }
    fun rc() {
        clipsBox.removeAllViews()
        clips.forEachIndexed { i, c ->
            clipsBox.addView(row(cbx("", c.on) { c.on = it; updExp() }, tv("${i + 1}. ${c.tag} ${fmtT(c.s)}–${fmtT(c.e)}", 13f).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) },
                btn("play", "") { player.seekTo(c.s); player.play() }, btn("trash", "") { clips.removeAt(i); rc() }))
        }
        if (clips.isEmpty()) clipsBox.addView(tv("No clips yet. Use Trim, Moments or Cut silence.", 13f, MU))
        updExp(); wave.invalidate()
    }
    fun totalSec() = clips.filter { it.on }.sumOf { it.e - it.s } / 1000.0 / SPEEDS[speedI]
    fun bitrateMbps(): Float = if (brI == 0) listOf(2f, 4f, 8f)[resI] else if (brI == spBr?.adapter?.count?.minus(1)) (if (custBr > 0) custBr else 4f) else BRS[brI]
    fun est() { if (::expInfo.isInitialized) { val s = clips.filter { it.on }; expInfo.text = "${s.size} clips · ${fmtT((totalSec() * 1000).toLong())} output · ≈ ${"%.0f".format(bitrateMbps() * totalSec() / 8)} MB at ${"%.1f".format(bitrateMbps())} Mbps" } }
    fun updExp() = est()
    fun rl() {
        layersBox.removeAllViews()
        tls.forEachIndexed { i, t -> layersBox.addView(row(tv("🔤 ${t.text}", 13f).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }, btn("trash", "") { tls.removeAt(i); rl() })) }
        ils.forEachIndexed { i, _ -> layersBox.addView(row(tv("🖼 Image ${i + 1}", 13f).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }, btn("trash", "") { ils.removeAt(i); rl() })) }
    }

    // ---------- Analysis ----------
    fun analyze(msg: String, done: (DoubleArray) -> Unit) {
        val u = cur ?: run { toast("Import a video first"); return }; val dur = player.duration
        rms?.let { done(it); return }
        showBusy("$msg\nReading audio... 0%")
        Thread {
            try { val r = audioRms(this, u, dur) { p -> busy("$msg\nReading audio... $p%") }; runOnUiThread { rms = r; wave.rms = r; wave.dur = dur; wave.invalidate(); hideBusy(); done(r) } }
            catch (e: Exception) { runOnUiThread { hideBusy(); toast("Analysis failed: ${e.message}") } }
        }.start()
    }
    fun normalize() = analyze("Measuring loudness") { r ->
        val v = r.filter { it > 0.01 }; val m = if (v.isEmpty()) 0.1 else v.average(); normGain = (0.1 / m).coerceIn(0.5, 4.0).toFloat(); toast("Loudness gain x${"%.1f".format(normGain)}")
    }
    fun autoLook() {
        val u = cur ?: run { toast("Import a video first"); return }; val dur = player.duration
        showBusy("Analyzing colours...")
        Thread {
            try { val g = autoGrade(this, u, dur) { p -> busy("Analyzing colours... $p%") }; runOnUiThread { hideBusy(); preset = 0; grade = g; warm = 0f; syncSliders(); toast("Auto look applied. Fine-tune below if you like.") } }
            catch (e: Exception) { runOnUiThread { hideBusy(); toast("Auto grade failed: ${e.message}") } }
        }.start()
    }
    fun silence(thrDb: Double, minSilMs: Long) = analyze("Cutting silence") { r ->
        val u = cur!!; val thr = Math.pow(10.0, thrDb / 20); val gap = (minSilMs / 50).toInt().coerceAtLeast(1)
        val out = ArrayList<Pair<Long, Long>>(); var st = -1; var last = -1
        for (i in r.indices) if (r[i] >= thr) { if (st < 0) st = i else if (i - last > gap) { out.add(Pair(st * 50L, (last + 1) * 50L)); st = i }; last = i }
        if (st >= 0) out.add(Pair(st * 50L, (last + 1) * 50L))
        val dur = player.duration
        out.map { Pair((it.first - 50).coerceAtLeast(0), (it.second + 50).coerceAtMost(dur)) }.filter { it.second - it.first > 300 }.forEach { clips.add(Clip(u, it.first, it.second, "Speech")) }
        rc(); showPanel(1)
    }
    fun addMoments() {
        val types = Moments.TYPES.filterIndexed { i, _ -> msel[i] }
        if (types.isEmpty()) { toast("Tick at least one moment type"); return }
        analyze("Analyzing full video for: ${types.joinToString()}") { r ->
            val hits = Moments.find(r, types, mLen, mK); val u = cur!!; val dur = player.duration
            clips.removeAll { it.auto }
            hits.forEach { clips.add(Clip(u, it.startS * 1000L, minOf(dur, it.endS * 1000L), "${Moments.ICONS[it.type]} ${it.type} #${it.rank}", true)) }
            rc(); showPanel(1); toast(if (hits.isEmpty()) "No strong moments found" else "${hits.size} moments added")
        }
    }

    // ---------- Subtitles ----------
    fun genSubs(key: String, lang: String?, whole: Boolean, hing: Boolean) {
        val u = cur ?: run { toast("Import a video first"); return }
        if (key.isBlank()) { toast("Paste your free Groq API key first"); return }
        prefs.edit().putString("groq", key).apply()
        val d = player.duration
        val raw = if (whole) (0 until ((d + 599999) / 600000).toInt()).map { Pair(it * 600000L, minOf(d, (it + 1) * 600000L)) } else clips.filter { it.on }.map { Pair(it.s, it.e) }.sortedBy { it.first }
        val ranges = ArrayList<Pair<Long, Long>>()
        raw.forEach { r -> if (ranges.isNotEmpty() && r.first <= ranges.last().second) ranges[ranges.size - 1] = Pair(ranges.last().first, maxOf(ranges.last().second, r.second)) else ranges.add(r) }
        if (ranges.isEmpty()) { toast("Add clips first, or choose Whole video"); return }
        showBusy("Generating subtitles...")
        Thread {
            try {
                val all = ArrayList<Cap>(); val f = File(cacheDir, "a.m4a")
                ranges.forEachIndexed { i, r ->
                    busy("Generating subtitles ${i + 1}/${ranges.size}")
                    val off = extractAudio(this, u, r.first, r.second, f); all.addAll(toCaps(whisper(key, f, lang), off, hing))
                    Thread.sleep(if (ranges.size > 15) 3200 else 300)
                }
                runOnUiThread { caps.clear(); caps.addAll(all); hideBusy(); capInfo.text = "${caps.size} subtitle lines ready"; if (caps.isEmpty()) toast("No speech found") }
            } catch (e: Exception) { runOnUiThread { hideBusy(); toast("Subtitles failed: ${e.message}") } }
        }.start()
    }

    // ---------- Export ----------
    fun staticOverlay(bm: Bitmap, x: Float, y: Float): TextureOverlay {
        val st = OverlaySettings.Builder().setBackgroundFrameAnchor(x, y).build()
        return object : BitmapOverlay() { override fun getBitmap(us: Long): Bitmap = bm; override fun getOverlaySettings(us: Long) = st }
    }
    fun item(c: Clip, ow: Int, oh: Int, fps: Int): EditedMediaItem {
        val mi = MediaItem.Builder().setUri(c.uri).setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.s).setEndPositionMs(c.e).build()).build()
        val sp = SPEEDS[speedI]; val v = ArrayList<Effect>()
        if (sp != 1f) v.add(SpeedChangeEffect(sp))
        v.add(LayoutEffect(mark.regs.map { RectF(it) }, chosen, split, swap, ow, oh))
        val g = grade.copyOf().apply { gr *= (1 + warm); gb *= (1 - warm) }; if (!g.isIdentity()) v.add(EnhanceEffect(g))
        if (fps < 30) v.add(FrameDropEffect.createDefaultFrameDropEffect(fps.toFloat()))
        val ov = ArrayList<TextureOverlay>(); val st = capStyle()
        if (capOn) { val cc = caps.filter { it.e > c.s && it.s < c.e }; if (cc.isNotEmpty()) ov.add(CapOverlay(cc, c.s, sp, ow, st)) }
        tls.forEach {
            val ws = it.text.split(" ").filter { w -> w.isNotEmpty() }; val px = ow * it.size
            ov.add(staticOverlay(Subs.render(ws, IntArray(ws.size) { _ -> it.color }, st.tf, px, (ow * 0.9f).toInt(), st.outFrac * px, st.outCol, st.shadow, 0), it.x, it.y))
        }
        ils.forEach { il ->
            val w = (ow * il.frac).toInt().coerceAtLeast(8); val hh = (w.toFloat() * il.bmp.height / il.bmp.width).toInt().coerceAtLeast(8)
            ov.add(staticOverlay(Bitmap.createScaledBitmap(il.bmp, w, hh, true), il.x, il.y))
        }
        if (ov.isNotEmpty()) v.add(OverlayEffect(ImmutableList.copyOf<TextureOverlay>(ov)))
        val a = ArrayList<AudioProcessor>(); val vol = listOf(0.5f, 1f, 1.5f, 2f)[volI] * (if (normOn) normGain else 1f)
        if (dnA > 0 || vol != 1f) a.add(AudioFx(dnA, vol))
        if (sp != 1f) a.add(SonicAudioProcessor().apply { setSpeed(sp); setPitch(1f) })
        return EditedMediaItem.Builder(mi).setRemoveAudio(mute).setEffects(Effects(a, v)).build()
    }

    fun startExport() {
        if (exporting) return
        val sel = clips.filter { it.on }; if (sel.isEmpty()) { toast("Select at least one clip"); return }
        jobs = if (mergeI == 1) listOf(sel) else sel.map { listOf(it) }
        jobI = 0; okN = 0; failN = 0; lastErr = ""; exporting = true; nextJob()
    }
    fun nextJob() {
        if (jobI >= jobs.size) {
            exporting = false; expBar.progress = 100
            status.text = "Finished: $okN saved to Movies/Clipper" + (if (failN > 0) ", $failN failed ($lastErr)" else ""); return
        }
        val q = listOf(480, 720, 1080)[resI]; val ar = ARS[arI]
        val ow = (if (ar < 1f) q else (q * ar).toInt()) / 2 * 2; val oh = (if (ar < 1f) (q / ar).toInt() else q) / 2 * 2; val fps = listOf(24, 30)[fpsI]
        val out = File(cacheDir, "out_$jobI.mp4"); out.delete(); val my = jobI
        val vs = VideoEncoderSettings.Builder().setBitrate((bitrateMbps() * 1_000_000).toInt()).build()
        val tr = Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setMaxDelayBetweenMuxerSamplesMs(C.TIME_UNSET)
            .setEncoderFactory(DefaultEncoderFactory.Builder(this).setRequestedVideoEncoderSettings(vs).build())
            .addListener(object : Transformer.Listener {
                override fun onCompleted(c: Composition, er: ExportResult) { try { save(out, my); okN++ } catch (e: Exception) { failN++; lastErr = "save: ${e.message}" }; jobI++; nextJob() }
                override fun onError(c: Composition, er: ExportResult, e: ExportException) { failN++; lastErr = "${e.errorCodeName} ${e.cause?.message ?: ""}".trim(); jobI++; nextJob() }
            }).build()
        try {
            val comp = Composition.Builder(EditedMediaItemSequence(jobs[my].map { item(it, ow, oh, fps) })).build()
            tr.start(comp, out.absolutePath)
        } catch (e: Exception) { failN++; lastErr = e.message ?: "start failed"; jobI++; nextJob(); return }
        val ph = ProgressHolder()
        h.post(object : Runnable { override fun run() {
            if (!exporting || jobI != my) return
            tr.getProgress(ph); status.text = "Exporting ${my + 1}/${jobs.size}  ·  ${ph.progress}%"
            expBar.progress = (my * 100 + ph.progress) / jobs.size; h.postDelayed(this, 500)
        } })
    }
    fun save(f: File, n: Int) {
        val cv = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, "clip_${System.currentTimeMillis()}_$n.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4"); put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Clipper") }
        val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
        contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        f.delete()
    }
    override fun onDestroy() { super.onDestroy(); h.removeCallbacksAndMessages(null); player.release() }
}
