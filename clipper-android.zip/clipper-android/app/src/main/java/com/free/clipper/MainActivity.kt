package com.free.clipper

import android.content.*
import android.graphics.*
import android.media.*
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.*
import androidx.media3.effect.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.*
import androidx.media3.ui.PlayerView
import com.google.common.collect.ImmutableList
import java.io.File
import java.nio.ByteOrder
import kotlin.math.pow
import kotlin.math.sqrt

data class Clip(val uri: Uri, val s: Long, val e: Long, val x: Float, val y: Float, val w: Float, val h: Float)
data class TextItem(val uri: Uri, val s: Long, val e: Long, val text: String, val color: Int, val y: Float)

class CropView(c: Context) : View(c) {
    var vw = 16; var vh = 9; var ratio = 9f / 16; var zoom = 1f; var bx = 0.3f; var by = 0f
    private val dim = Paint().apply { color = 0x99000000.toInt() }
    private val line = Paint().apply { color = Color.GREEN; style = Paint.Style.STROKE; strokeWidth = 5f }
    private var lx = 0f; private var ly = 0f
    private fun vrect(): RectF {
        val a = vw.toFloat() / vh; val W = width.toFloat(); val H = height.toFloat()
        val rw = if (W / H > a) H * a else W; val rh = if (W / H > a) H else W / a
        return RectF((W - rw) / 2, (H - rh) / 2, (W + rw) / 2, (H + rh) / 2)
    }
    fun cw() = minOf(1f, vh * ratio / vw) * zoom
    fun ch() = cw() * vw / (vh * ratio)
    override fun onDraw(c: Canvas) {
        bx = bx.coerceIn(0f, 1f - cw()); by = by.coerceIn(0f, 1f - ch())
        val r = vrect()
        val b = RectF(r.left + bx * r.width(), r.top + by * r.height(), r.left + (bx + cw()) * r.width(), r.top + (by + ch()) * r.height())
        c.drawRect(r.left, r.top, r.right, b.top, dim); c.drawRect(r.left, b.bottom, r.right, r.bottom, dim)
        c.drawRect(r.left, b.top, b.left, b.bottom, dim); c.drawRect(b.right, b.top, r.right, b.bottom, dim)
        c.drawRect(b, line)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) { lx = e.x; ly = e.y }
        if (e.action == MotionEvent.ACTION_MOVE) {
            val r = vrect(); bx += (e.x - lx) / r.width(); by += (e.y - ly) / r.height(); lx = e.x; ly = e.y; invalidate()
        }
        return true
    }
}

class MainActivity : AppCompatActivity() {
    lateinit var player: ExoPlayer; lateinit var crop: CropView
    lateinit var info: TextView; lateinit var clipsBox: LinearLayout; lateinit var textsBox: LinearLayout; lateinit var status: TextView
    var cur: Uri? = null; var ms = 0L; var me = 0L
    val clips = ArrayList<Clip>(); val texts = ArrayList<TextItem>()
    val ratios = listOf("9:16", "1:1", "4:5", "16:9"); val ratioVals = listOf(9f / 16, 1f, 4f / 5, 16f / 9)
    var ri = 0; var resI = 1; var fpsI = 1; var colI = 0; var posI = 2
    val colors = listOf(Color.WHITE, Color.YELLOW, Color.RED, Color.GREEN, Color.CYAN)
    val ys = listOf(0.7f, 0f, -0.7f)
    val h = Handler(Looper.getMainLooper())

    fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    fun sp(items: List<String>, init: Int, cb: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items); setSelection(init)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { cb(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }
    fun row(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; v.forEach { addView(it) } }
    fun num(hint: String, def: String) = EditText(this).apply { setText(def); this.hint = hint; inputType = 4098 or 8192; minEms = 4 }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(v: VideoSize) { crop.vw = maxOf(1, v.width); crop.vh = maxOf(1, v.height); crop.invalidate() }
            override fun onPlaybackStateChanged(s: Int) { if (s == Player.STATE_READY && me == 0L) { me = player.duration; upd() } }
        })
        val pv = PlayerView(this).apply { this.player = this@MainActivity.player }
        crop = CropView(this)
        val fl = FrameLayout(this).apply { addView(pv); addView(crop) }
        info = TextView(this); clipsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; status = TextView(this)
        val zoom = SeekBar(this).apply { max = 80; progress = 80
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { crop.zoom = (p + 20) / 100f; crop.invalidate() }
                override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
            }) }
        val db = num("dB", "-30"); val minMs = num("min ms", "500"); val txt = EditText(this).apply { hint = "Text likho" }
        val tsz = num("", "0"); val br = num("kbps", "0")
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        listOf<View>(
            btn("Video import") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "video/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 1) },
            fl.apply { layoutParams = LinearLayout.LayoutParams(-1, 700) },
            row(TextView(this).apply { text = "Crop ratio " }, sp(ratios, 0) { ri = it; crop.ratio = ratioVals[it]; crop.invalidate() }), zoom,
            row(btn("Start yahan") { ms = player.currentPosition; upd() }, btn("End yahan") { me = player.currentPosition; upd() }), info,
            row(btn("Clip add") { cur?.let { clips.add(mk(it, ms, me)); rc() } }, btn("Split yahan") { split() }),
            row(db, minMs, btn("Auto silence cut") { silence(db.text.toString().toDoubleOrNull() ?: -30.0, minMs.text.toString().toLongOrNull() ?: 500) }),
            clipsBox, txt,
            row(sp(listOf("Safed", "Peela", "Laal", "Hara", "Cyan"), 0) { colI = it }, sp(listOf("Upar", "Beech", "Neeche"), 2) { posI = it },
                btn("Text add") { cur?.let { u -> if (txt.text.isNotBlank()) { texts.add(TextItem(u, ms, me, txt.text.toString(), colors[colI], ys[posI])); txt.setText(""); rt() } } }),
            textsBox,
            row(sp(listOf("480p", "720p", "1080p"), 1) { resI = it }, sp(listOf("24 fps", "30 fps", "60 fps"), 1) { fpsI = it }, br),
            btn("EXPORT") { export(br.text.toString().toIntOrNull() ?: 0) }, status
        ).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        val u = d?.data ?: return
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        cur = u; ms = 0; me = 0; player.setMediaItem(MediaItem.fromUri(u)); player.prepare()
    }
    fun upd() { info.text = "Start ${ms / 1000.0}s  End ${me / 1000.0}s" }
    fun mk(u: Uri, s: Long, e: Long) = Clip(u, s, e, crop.bx, crop.by, crop.cw(), crop.ch())
    fun split() {
        val u = cur ?: return; val t = player.currentPosition
        var i = clips.indexOfFirst { it.uri == u && t > it.s && t < it.e }
        if (i < 0) { clips.add(mk(u, 0, player.duration)); i = clips.size - 1 }
        val c = clips[i]; clips[i] = c.copy(e = t); clips.add(i + 1, c.copy(s = t)); rc()
    }
    fun rc() {
        clipsBox.removeAllViews()
        clips.forEachIndexed { i, c ->
            clipsBox.addView(row(TextView(this).apply { text = "${i + 1}. ${c.s / 1000.0}s - ${c.e / 1000.0}s  " },
                btn("↑") { if (i > 0) { clips.add(i - 1, clips.removeAt(i)); rc() } }, btn("↓") { if (i < clips.size - 1) { clips.add(i + 1, clips.removeAt(i)); rc() } },
                btn("✕") { clips.removeAt(i); rc() }))
        }
    }
    fun rt() {
        textsBox.removeAllViews()
        texts.forEachIndexed { i, t -> textsBox.addView(row(TextView(this).apply { text = "\"${t.text}\" ${t.s / 1000.0}-${t.e / 1000.0}s  " }, btn("✕") { texts.removeAt(i); rt() })) }
    }

    fun silence(thrDb: Double, minSilMs: Long) {
        val u = cur ?: return; val dur = player.duration; status.text = "Silence dhoondh raha hai..."
        Thread {
            try {
                val segs = speech(u, thrDb, minSilMs, dur)
                runOnUiThread { segs.forEach { clips.add(mk(u, it.first, it.second)) }; rc(); status.text = "${segs.size} clips bane" }
            } catch (e: Exception) { runOnUiThread { status.text = "Error: ${e.message}" } }
        }.start()
    }

    fun speech(u: Uri, thrDb: Double, minSilMs: Long, dur: Long): List<Pair<Long, Long>> {
        val ex = MediaExtractor(); ex.setDataSource(this, u, null)
        val ti = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
        ex.selectTrack(ti); val f = ex.getTrackFormat(ti)
        val dec = MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME)!!); dec.configure(f, null, null, 0); dec.start()
        val info = MediaCodec.BufferInfo(); val rms = ArrayList<Double>()
        var inDone = false; var outDone = false; var sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); var ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var sum = 0.0; var n = 0
        while (!outDone) {
            if (!inDone) {
                val i = dec.dequeueInputBuffer(5000)
                if (i >= 0) {
                    val sz = ex.readSampleData(dec.getInputBuffer(i)!!, 0)
                    if (sz < 0) { dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                    else { dec.queueInputBuffer(i, 0, sz, ex.sampleTime, 0); ex.advance() }
                }
            }
            val o = dec.dequeueOutputBuffer(info, 5000)
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { sr = dec.outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = dec.outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) }
            else if (o >= 0) {
                val sb = dec.getOutputBuffer(o)!!.order(ByteOrder.nativeOrder()).asShortBuffer(); val per = (sr * ch * 0.05).toInt()
                while (sb.hasRemaining()) { val s = sb.get().toDouble(); sum += s * s; n++; if (n >= per) { rms.add(sqrt(sum / n) / 32768.0); sum = 0.0; n = 0 } }
                dec.releaseOutputBuffer(o, false); if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
            }
        }
        dec.stop(); dec.release(); ex.release()
        val thr = 10.0.pow(thrDb / 20); val gap = (minSilMs / 50).toInt().coerceAtLeast(1)
        val out = ArrayList<Pair<Long, Long>>(); var st = -1; var last = -1
        for (i in rms.indices) {
            if (rms[i] >= thr) { if (st < 0) st = i else if (i - last > gap) { out.add(Pair(st * 50L, (last + 1) * 50L)); st = i }; last = i }
        }
        if (st >= 0) out.add(Pair(st * 50L, (last + 1) * 50L))
        return out.map { Pair((it.first - 50).coerceAtLeast(0), (it.second + 50).coerceAtMost(dur)) }.filter { it.second - it.first > 300 }
    }

    fun item(c: Clip, ow: Int, oh: Int, fps: Int): EditedMediaItem {
        val mi = MediaItem.Builder().setUri(c.uri).setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.s).setEndPositionMs(c.e).build()).build()
        val v = ArrayList<Effect>()
        v.add(Crop(-1f + 2 * c.x, -1f + 2 * (c.x + c.w), 1f - 2 * (c.y + c.h), 1f - 2 * c.y))
        v.add(Presentation.createForWidthAndHeight(ow, oh, Presentation.LAYOUT_SCALE_TO_FIT))
        if (fps < 30) v.add(FrameDropEffect.createDefaultFrameDropEffect(fps.toFloat()))
        val ov = texts.filter { it.uri == c.uri && it.e > c.s && it.s < c.e }.map { t ->
            val sp = SpannableString(t.text).apply { setSpan(ForegroundColorSpan(t.color), 0, length, 0); setSpan(AbsoluteSizeSpan((ow * 0.07f).toInt()), 0, length, 0) }
            val off = SpannableString(" "); val st = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, t.y).build()
            object : TextOverlay() {
                override fun getText(us: Long): SpannableString { val m = us / 1000 + c.s; return if (m >= t.s && m <= t.e) sp else off }
                override fun getOverlaySettings(us: Long) = st
            } as TextureOverlay
        }
        if (ov.isNotEmpty()) v.add(OverlayEffect(ImmutableList.copyOf(ov)))
        return EditedMediaItem.Builder(mi).setEffects(Effects(emptyList(), v)).build()
    }

    fun export(br: Int) {
        if (clips.isEmpty()) { status.text = "Pehle Clip add / Split / Silence cut karo"; return }
        val q = listOf(480, 720, 1080)[resI]; val r = ratioVals[ri]
        val ow = (if (r < 1) q else (q * r).toInt()) / 2 * 2; val oh = (if (r < 1) (q / r).toInt() else q) / 2 * 2
        val fps = listOf(24, 30, 60)[fpsI]
        val out = File(cacheDir, "out.mp4"); out.delete()
        val vs = VideoEncoderSettings.Builder().apply { if (br > 0) setBitrate(br * 1000) }.build()
        val tr = Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(DefaultEncoderFactory.Builder(this).setRequestedVideoEncoderSettings(vs).build())
            .addListener(object : Transformer.Listener {
                override fun onCompleted(c: Composition, er: ExportResult) { save(out) }
                override fun onError(c: Composition, er: ExportResult, e: ExportException) { status.text = "Export error: ${e.message}" }
            }).build()
        val comp = Composition.Builder(EditedMediaItemSequence(clips.map { item(it, ow, oh, fps) })).build()
        tr.start(comp, out.absolutePath); status.text = "Export ho raha hai..."
        val ph = ProgressHolder()
        h.post(object : Runnable { override fun run() {
            val t = status.text.toString()
            if (t.startsWith("Done") || t.startsWith("Export error")) return
            tr.getProgress(ph); status.text = "Export: ${ph.progress}%"; h.postDelayed(this, 700)
        } })
    }

    fun save(f: File) {
        val cv = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, "clip_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4"); put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Clipper") }
        val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
        contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        status.text = "Done! Gallery > Movies/Clipper me save ho gaya"
    }
}
