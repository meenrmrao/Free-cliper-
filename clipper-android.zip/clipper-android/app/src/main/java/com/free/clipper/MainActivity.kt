package com.free.clipper

import android.content.*
import android.graphics.*
import android.media.*
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.*
import androidx.media3.effect.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.*
import androidx.media3.ui.PlayerView
import com.google.common.collect.ImmutableList
import java.io.File
import java.nio.ByteOrder
import kotlin.math.pow
import kotlin.math.sqrt

data class Clip(val uri: Uri, val s: Long, val e: Long, val tag: String = "")
data class TextItem(val s: Long, val e: Long, val text: String, val color: Int, val y: Float)

fun fitRect(w: Float, h: Float, vw: Int, vh: Int): RectF {
    val a = vw.toFloat() / vh; val rw = if (w / h > a) h * a else w; val rh = if (w / h > a) h else w / a
    return RectF((w - rw) / 2, (h - rh) / 2, (w + rw) / 2, (h + rh) / 2)
}

/** Draw / move / resize up to 3 areas on top of the video */
class MarkView(c: Context) : View(c) {
    var vw = 16; var vh = 9; val regs = ArrayList<RectF>(); var act = -1
    private val cols = intArrayOf(Color.GREEN, Color.CYAN, Color.YELLOW)
    private val p = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 6f }
    private val t = Paint().apply { textSize = 56f; isFakeBoldText = true }
    private var lx = 0f; private var ly = 0f; private var mode = 0
    override fun onDraw(c: Canvas) {
        val r = fitRect(width.toFloat(), height.toFloat(), vw, vh)
        regs.forEachIndexed { i, g ->
            val b = RectF(r.left + g.left * r.width(), r.top + g.top * r.height(), r.left + g.right * r.width(), r.top + g.bottom * r.height())
            p.color = cols[i]; p.strokeWidth = if (i == act) 9f else 4f; c.drawRect(b, p)
            t.color = cols[i]; c.drawText("${i + 1}", b.left + 12, b.top + 56, t)
            if (i == act) { p.style = Paint.Style.FILL; c.drawRect(b.right - 36, b.bottom - 36, b.right, b.bottom, p); p.style = Paint.Style.STROKE }
        }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val r = fitRect(width.toFloat(), height.toFloat(), vw, vh)
        val nx = (e.x - r.left) / r.width(); val ny = (e.y - r.top) / r.height()
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                parent.requestDisallowInterceptTouchEvent(true); lx = e.x; ly = e.y; mode = 0
                val a = regs.getOrNull(act)
                if (a != null && Math.abs(e.x - (r.left + a.right * r.width())) < 70 && Math.abs(e.y - (r.top + a.bottom * r.height())) < 70) mode = 2
                else { val i = regs.indexOfLast { it.contains(nx, ny) }; if (i >= 0) { act = i; mode = 1; invalidate() } }
            }
            MotionEvent.ACTION_MOVE -> {
                val g = regs.getOrNull(act) ?: return true
                val dx = (e.x - lx) / r.width(); val dy = (e.y - ly) / r.height(); lx = e.x; ly = e.y
                if (mode == 1) { val ddx = dx.coerceIn(-g.left, 1f - g.right); val ddy = dy.coerceIn(-g.top, 1f - g.bottom); g.offset(ddx, ddy) }
                if (mode == 2) { g.right = (g.right + dx).coerceIn(g.left + 0.05f, 1f); g.bottom = (g.bottom + dy).coerceIn(g.top + 0.05f, 1f) }
                invalidate()
            }
        }
        return true
    }
}

/** Shows the chosen layout on a real frame of the video (9:16 output) */
class PreviewView(c: Context) : View(c) {
    var bmp: Bitmap? = null; var regs: List<RectF> = emptyList(); var layout = Layout.SINGLE; var split = 0.4f; var swap = false
    private val bg = Paint().apply { color = Color.BLACK }
    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        val oh = height * 0.96f; val ow = oh * 9 / 16; val x0 = (width - ow) / 2; val y0 = height * 0.02f
        c.drawRect(x0, y0, x0 + ow, y0 + oh, bg)
        buildLayers(b.width, b.height, regs, layout, split, swap, 1080, 1920).forEach { l ->
            val src = Rect((l.src.left * b.width).toInt(), (l.src.top * b.height).toInt(), (l.src.right * b.width).toInt(), (l.src.bottom * b.height).toInt())
            val dst = RectF(x0 + l.out.left * ow, y0 + l.out.top * oh, x0 + l.out.right * ow, y0 + l.out.bottom * oh)
            c.drawBitmap(b, src, dst, null)
        }
    }
}

class MainActivity : AppCompatActivity() {
    lateinit var player: ExoPlayer; lateinit var mark: MarkView; lateinit var prev: PreviewView; lateinit var pf: FrameLayout
    lateinit var p1: LinearLayout; lateinit var p2: LinearLayout; lateinit var p3: LinearLayout
    lateinit var info: TextView; lateinit var clipsBox: LinearLayout; lateinit var textsBox: LinearLayout; lateinit var status: TextView; lateinit var areaInfo: TextView
    var rbs = listOf<RadioButton>(); val need = listOf(1, 2, 3, 2); val layouts = Layout.values()
    var cur: Uri? = null; var ms = 0L; var me = 0L; var rms: DoubleArray? = null
    val clips = ArrayList<Clip>(); val texts = ArrayList<TextItem>()
    var layout = Layout.SPLIT; var split = 0.4f; var swap = false
    var resI = 1; var fpsI = 1; var colI = 0; var posI = 2
    val colors = listOf(Color.WHITE, Color.YELLOW, Color.RED, Color.GREEN, Color.CYAN); val ys = listOf(0.7f, 0f, -0.7f)
    val h = Handler(Looper.getMainLooper())

    fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    fun head(t: String) = TextView(this).apply { text = t; textSize = 18f; setPadding(0, 24, 0, 8); setTypeface(null, Typeface.BOLD) }
    fun sp(items: List<String>, init: Int, cb: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items); setSelection(init)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { cb(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }
    fun row(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; v.forEach { addView(it) } }
    fun col(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; v.forEach { addView(it) } }
    fun num(hint: String, def: String) = EditText(this).apply { setText(def); this.hint = hint; inputType = 4098 or 8192; minEms = 4 }
    fun bar(max: Int, prog: Int, cb: (Int) -> Unit) = SeekBar(this).apply { this.max = max; progress = prog
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { cb(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
        }) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(v: VideoSize) { mark.vw = maxOf(1, v.width); mark.vh = maxOf(1, v.height); mark.invalidate() }
            override fun onPlaybackStateChanged(s: Int) { if (s == Player.STATE_READY && me == 0L) { me = player.duration; upd() } }
        })
        mark = MarkView(this); prev = PreviewView(this)
        pf = FrameLayout(this).apply { addView(PlayerView(this@MainActivity).apply { this.player = this@MainActivity.player }); addView(mark); layoutParams = LinearLayout.LayoutParams(-1, 700) }
        info = TextView(this); status = TextView(this); areaInfo = TextView(this)
        clipsBox = col(); textsBox = col()

        // STEP 1: mark areas
        p1 = col(head("Step 1 of 3 - Mark areas"),
            TextView(this).apply { text = "Import a video, pause on a frame where everything is visible, then mark the areas you want in the vertical video (e.g. 1 = facecam, 2 = gameplay). Drag a box to move it, drag its corner square to resize." },
            row(btn("Import video") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "video/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 1) },
                btn("+ Add area") { if (cur != null && mark.regs.size < 3) { val k = mark.regs.size * 0.05f; mark.regs.add(RectF(0.2f + k, 0.2f + k, 0.5f + k, 0.5f + k)); mark.act = mark.regs.size - 1; mark.invalidate(); areaInfo.text = "Areas marked: ${mark.regs.size}" } }),
            row(btn("Delete area") { if (mark.act >= 0) { mark.regs.removeAt(mark.act); mark.act = mark.regs.size - 1; mark.invalidate(); areaInfo.text = "Areas marked: ${mark.regs.size}" } },
                btn("Next >") { if (mark.regs.isEmpty()) areaInfo.text = "Add at least one area first" else go(2) }), areaInfo)

        // STEP 2: layout
        val rg = RadioGroup(this)
        rbs = listOf("Single area (area 1 full screen)", "Split (area 1 top, area 2 bottom)", "3-part stack (areas 1, 2, 3)", "Picture-in-picture (area 1 small over area 2)").mapIndexed { i, t ->
            RadioButton(this).apply { text = t; id = View.generateViewId(); setOnClickListener { layout = layouts[i]; refresh() } }.also { rg.addView(it) } }
        p2 = col(head("Step 2 of 3 - Choose layout"), prev.apply { layoutParams = LinearLayout.LayoutParams(-1, 1100) }, rg,
            CheckBox(this).apply { text = "Swap order of areas"; setOnCheckedChangeListener { _, c -> swap = c; refresh() } },
            TextView(this).apply { text = "Size of first section" }, bar(35, 15) { split = (25 + it) / 100f; refresh() },
            row(btn("< Back") { go(1) }, btn("Next >") { go(3) }))

        // STEP 3: edit
        val db = num("dB", "-30"); val minMs = num("min ms", "500"); val txt = EditText(this).apply { hint = "Type text" }; val br = num("kbps", "0")
        var hl = 30; var hk = 5
        p3 = col(head("Step 3 of 3 - Edit & Export"),
            head("Auto Highlights"),
            TextView(this).apply { text = "Analyzes the audio of the whole video (loud moments, screams, laughs, hype) and picks the best moments as clips." },
            row(sp(listOf("15 sec", "30 sec", "45 sec", "60 sec"), 1) { hl = listOf(15, 30, 45, 60)[it] }, sp(listOf("Top 3", "Top 5", "Top 8"), 1) { hk = listOf(3, 5, 8)[it] },
                btn("Find best moments") { highlight(hl, hk) }),
            head("Trim & Split"),
            row(btn("Set start") { ms = player.currentPosition; upd() }, btn("Set end") { me = player.currentPosition; upd() }), info,
            row(btn("Add clip") { cur?.let { clips.add(Clip(it, ms, me)); rc() } }, btn("Split here") { split() },
                btn("Auto silence cut") { silence(db.text.toString().toDoubleOrNull() ?: -30.0, minMs.text.toString().toLongOrNull() ?: 500) }),
            row(TextView(this).apply { text = "Silence dB / min ms " }, db, minMs),
            head("Clips (exported in this order)"), clipsBox,
            head("Add text"), txt,
            row(sp(listOf("White", "Yellow", "Red", "Green", "Cyan"), 0) { colI = it }, sp(listOf("Top", "Middle", "Bottom"), 2) { posI = it },
                btn("Add text") { if (txt.text.isNotBlank()) { texts.add(TextItem(ms, me, txt.text.toString(), colors[colI], ys[posI])); txt.setText(""); rt() } }), textsBox,
            head("Export"),
            row(sp(listOf("480p", "720p", "1080p"), 1) { resI = it }, sp(listOf("24 fps", "30 fps", "60 fps"), 1) { fpsI = it }, br),
            btn("EXPORT") { export(br.text.toString().toIntOrNull() ?: 0) }, status, btn("< Back") { go(2) })

        val root = col(pf, p1, p2, p3).apply { setPadding(24, 24, 24, 24) }
        setContentView(ScrollView(this).apply { addView(root) }); go(1)
    }

    fun go(n: Int) {
        pf.visibility = if (n == 2) View.GONE else View.VISIBLE; mark.visibility = if (n == 1) View.VISIBLE else View.GONE
        p1.visibility = if (n == 1) View.VISIBLE else View.GONE; p2.visibility = if (n == 2) View.VISIBLE else View.GONE; p3.visibility = if (n == 3) View.VISIBLE else View.GONE
        if (n == 2) {
            player.pause()
            val mr = MediaMetadataRetriever(); try { mr.setDataSource(this, cur); prev.bmp = mr.getFrameAtTime(player.currentPosition * 1000, MediaMetadataRetriever.OPTION_CLOSEST) } catch (_: Exception) {} finally { mr.release() }
            rbs.forEachIndexed { i, rb -> rb.isEnabled = mark.regs.size >= need[i] }
            if (mark.regs.size < need[layouts.indexOf(layout)]) layout = if (mark.regs.size >= 2) Layout.SPLIT else Layout.SINGLE
            rbs[layouts.indexOf(layout)].isChecked = true; refresh()
        }
        if (n == 3) { status.text = ""; upd() }
    }
    fun refresh() { prev.regs = mark.regs.map { RectF(it) }; prev.layout = layout; prev.split = split; prev.swap = swap; prev.invalidate() }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        val u = d?.data ?: return
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        cur = u; ms = 0; me = 0; rms = null; clips.clear(); texts.clear(); mark.regs.clear(); mark.act = -1; rc(); rt(); areaInfo.text = "Areas marked: 0"
        player.setMediaItem(MediaItem.fromUri(u)); player.prepare(); mark.invalidate()
    }
    fun upd() { info.text = "Start ${ms / 1000.0}s   End ${me / 1000.0}s" }
    fun split() {
        val u = cur ?: return; val t = player.currentPosition
        var i = clips.indexOfFirst { it.uri == u && t > it.s && t < it.e }
        if (i < 0) { clips.add(Clip(u, 0, player.duration)); i = clips.size - 1 }
        val c = clips[i]; clips[i] = c.copy(e = t); clips.add(i + 1, c.copy(s = t, tag = "")); rc()
    }
    fun rc() {
        clipsBox.removeAllViews()
        clips.forEachIndexed { i, c ->
            clipsBox.addView(row(TextView(this).apply { text = "${i + 1}. ${c.tag} ${c.s / 1000}s - ${c.e / 1000}s  " }, btn("Play") { player.seekTo(c.s); player.play() },
                btn("↑") { if (i > 0) { clips.add(i - 1, clips.removeAt(i)); rc() } }, btn("↓") { if (i < clips.size - 1) { clips.add(i + 1, clips.removeAt(i)); rc() } },
                btn("X") { clips.removeAt(i); rc() }))
        }
    }
    fun rt() {
        textsBox.removeAllViews()
        texts.forEachIndexed { i, t -> textsBox.addView(row(TextView(this).apply { text = "\"${t.text}\" ${t.s / 1000.0}-${t.e / 1000.0}s  " }, btn("X") { texts.removeAt(i); rt() })) }
    }

    fun analyze(done: (DoubleArray?, String?) -> Unit) {
        val u = cur ?: return; val dur = player.duration
        rms?.let { done(it, null); return }
        status.text = "Analyzing audio... (long videos can take a few minutes)"
        Thread {
            try { val r = audioRms(u, dur); runOnUiThread { rms = r; done(r, null) } } catch (e: Exception) { runOnUiThread { done(null, e.message) } }
        }.start()
    }
    fun silence(thrDb: Double, minSilMs: Long) = analyze { r, err ->
        if (r == null) { status.text = "Error: $err"; return@analyze }
        val u = cur!!; val thr = 10.0.pow(thrDb / 20); val gap = (minSilMs / 50).toInt().coerceAtLeast(1)
        val out = ArrayList<Pair<Long, Long>>(); var st = -1; var last = -1
        for (i in r.indices) if (r[i] >= thr) { if (st < 0) st = i else if (i - last > gap) { out.add(Pair(st * 50L, (last + 1) * 50L)); st = i }; last = i }
        if (st >= 0) out.add(Pair(st * 50L, (last + 1) * 50L))
        val dur = player.duration; var n = 0
        out.map { Pair((it.first - 50).coerceAtLeast(0), (it.second + 50).coerceAtMost(dur)) }.filter { it.second - it.first > 300 }.forEach { clips.add(Clip(u, it.first, it.second)); n++ }
        rc(); status.text = "$n clips created"
    }
    fun highlight(len: Int, k: Int) = analyze { r, err ->
        if (r == null) { status.text = "Error: $err"; return@analyze }
        val u = cur!!; val sec = r.size / 20
        if (sec < len + 2) { status.text = "Video is too short for this clip length"; return@analyze }
        val mean = DoubleArray(sec) { s -> (0 until 20).sumOf { r[s * 20 + it] } / 20 }
        val peak = DoubleArray(sec) { s -> (0 until 20).maxOf { r[s * 20 + it] } }
        fun roll(a: DoubleArray, s: Int): Double { val lo = maxOf(0, s - 60); val hi = minOf(sec - 1, s + 60); var t = 0.0; for (i in lo..hi) t += a[i]; return t / (hi - lo + 1) }
        val raw = DoubleArray(sec) { s -> if (mean[s] < 0.01) 0.0 else 0.6 * mean[s] / maxOf(roll(mean, s), 0.005) + 0.4 * peak[s] / maxOf(roll(peak, s), 0.01) }
        val sc = DoubleArray(sec) { s -> var t = 0.0; var c = 0; for (i in maxOf(0, s - 2)..minOf(sec - 1, s + 2)) { t += raw[i]; c++ }; t / c }
        val picked = ArrayList<Int>()
        for (s in sc.indices.sortedByDescending { sc[it] }) { if (picked.size >= k) break; if (sc[s] > 0 && picked.none { Math.abs(it - s) < len }) picked.add(s) }
        val dur = player.duration
        picked.sorted().forEach { p ->
            var st = (p - (len * 0.6).toInt()).coerceAtLeast(0); if (st + len > sec) st = sec - len
            clips.add(Clip(u, st * 1000L, minOf(dur, (st + len) * 1000L), "[Best ${"%.1f".format(sc[p])}]"))
        }
        rc(); status.text = "${picked.size} best moments added. Tap Play to review, X to remove."
    }

    /** RMS loudness for every 50 ms of audio */
    fun audioRms(u: Uri, dur: Long): DoubleArray {
        val ex = MediaExtractor(); ex.setDataSource(this, u, null)
        val ti = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
        ex.selectTrack(ti); val f = ex.getTrackFormat(ti)
        val dec = MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME)!!); dec.configure(f, null, null, 0); dec.start()
        val info = MediaCodec.BufferInfo(); val rms = ArrayList<Double>()
        var inDone = false; var outDone = false; var sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE); var ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var sum = 0.0; var n = 0; var lastP = 0L
        while (!outDone) {
            if (!inDone) {
                val i = dec.dequeueInputBuffer(5000)
                if (i >= 0) {
                    val sz = ex.readSampleData(dec.getInputBuffer(i)!!, 0)
                    if (sz < 0) { dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                    else { val t = ex.sampleTime; dec.queueInputBuffer(i, 0, sz, t, 0); ex.advance()
                        if (dur > 0 && t / 1000 - lastP > dur / 20) { lastP = t / 1000; val pc = lastP * 100 / dur; runOnUiThread { status.text = "Analyzing audio... $pc%" } } }
                }
            }
            val o = dec.dequeueOutputBuffer(info, 5000)
            if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { sr = dec.outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE); ch = dec.outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) }
            else if (o >= 0) {
                val sb = dec.getOutputBuffer(o)!!.order(ByteOrder.nativeOrder()).asShortBuffer(); val per = (sr * ch * 0.05).toInt()
                while (sb.hasRemaining()) { val s = sb.get().toDouble(); sum += s * s; n++; if (n >= per) { rms.add(sqrt(sum / n) / 32768.0); sum = 0.0; n = 0 } }
                dec.releaseOutputBuffer(o, false); if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
            }
        }
        dec.stop(); dec.release(); ex.release()
        return rms.toDoubleArray()
    }

    fun item(c: Clip, ow: Int, oh: Int, fps: Int): EditedMediaItem {
        val mi = MediaItem.Builder().setUri(c.uri).setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.s).setEndPositionMs(c.e).build()).build()
        val v = ArrayList<Effect>()
        v.add(LayoutEffect(mark.regs.map { RectF(it) }, layout, split, swap, ow, oh))
        if (fps < 30) v.add(FrameDropEffect.createDefaultFrameDropEffect(fps.toFloat()))
        val ov = texts.filter { it.e > c.s && it.s < c.e }.map { t ->
            val sp = SpannableString(t.text).apply { setSpan(ForegroundColorSpan(t.color), 0, length, 0); setSpan(AbsoluteSizeSpan((ow * 0.07f).toInt()), 0, length, 0) }
            val off = SpannableString(" "); val st = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, t.y).build()
            object : TextOverlay() {
                override fun getText(us: Long): SpannableString { val m = us / 1000 + c.s; return if (m >= t.s && m <= t.e) sp else off }
                override fun getOverlaySettings(us: Long) = st
            } as TextureOverlay
        }
        if (ov.isNotEmpty()) v.add(OverlayEffect(ImmutableList.copyOf(ov)))
        return EditedMediaItem.Builder(mi).setEffects(Effects(emptyList(), v)).build()
    }

    fun export(br: Int) {
        if (clips.isEmpty()) { status.text = "Add clips first (Add clip / Split / Silence cut / Best moments)"; return }
        val ow = listOf(480, 720, 1080)[resI] / 2 * 2; val oh = (ow * 16 / 9) / 2 * 2; val fps = listOf(24, 30, 60)[fpsI]
        val out = File(cacheDir, "out.mp4"); out.delete()
        val vs = VideoEncoderSettings.Builder().apply { if (br > 0) setBitrate(br * 1000) }.build()
        val tr = Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(DefaultEncoderFactory.Builder(this).setRequestedVideoEncoderSettings(vs).build())
            .addListener(object : Transformer.Listener {
                override fun onCompleted(c: Composition, er: ExportResult) { save(out) }
                override fun onError(c: Composition, er: ExportResult, e: ExportException) { status.text = "Export error: ${e.message}" }
            }).build()
        val comp = Composition.Builder(EditedMediaItemSequence(clips.map { item(it, ow, oh, fps) })).build()
        tr.start(comp, out.absolutePath); status.text = "Exporting..."
        val ph = ProgressHolder()
        h.post(object : Runnable { override fun run() {
            val t = status.text.toString()
            if (t.startsWith("Done") || t.startsWith("Export error")) return
            tr.getProgress(ph); status.text = "Exporting: ${ph.progress}%"; h.postDelayed(this, 700)
        } })
    }

    fun save(f: File) {
        val cv = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, "clip_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4"); put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Clipper") }
        val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
        contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        status.text = "Done! Saved in Gallery > Movies/Clipper"
    }
}
