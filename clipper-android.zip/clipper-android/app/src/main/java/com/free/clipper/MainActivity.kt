package com.free.clipper

import android.content.*
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.text.InputType
import android.text.SpannableString
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.*
import androidx.media3.effect.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.*
import androidx.media3.ui.PlayerView
import com.google.common.collect.ImmutableList
import java.io.File

data class Clip(val uri: Uri, val s: Long, val e: Long, val tag: String = "", val auto: Boolean = false, var on: Boolean = true)
class TLayer(val text: String, val color: Int, val size: Float, val x: Float, val y: Float)
class ILayer(val bmp: Bitmap, val frac: Float, val x: Float, val y: Float)

class MainActivity : AppCompatActivity() {
    val BG = 0xFF0E1013.toInt(); val SF = 0xFF181B21.toInt(); val SF2 = 0xFF262B35.toInt(); val AC = 0xFF6C5CE7.toInt(); val TX = 0xFFEAECEF.toInt(); val MU = 0xFF9AA0AC.toInt()
    lateinit var player: ExoPlayer; lateinit var mark: MarkView; lateinit var prev: PreviewView; lateinit var pf: FrameLayout
    lateinit var p1: LinearLayout; lateinit var p2: ScrollView; lateinit var p3: LinearLayout
    lateinit var areaInfo: TextView; lateinit var info: TextView; lateinit var clipsBox: LinearLayout; lateinit var layersBox: LinearLayout
    lateinit var capInfo: TextView; lateinit var expInfo: TextView; lateinit var status: TextView; lateinit var expBar: ProgressBar
    lateinit var dlgText: TextView; var dlg: AlertDialog? = null
    var rbs = listOf<RadioButton>(); val need = listOf(1, 2, 3, 2); val layouts = Layout.values()
    var panels = listOf<View>(); var tiles = listOf<View>()
    var cur: Uri? = null; var ms = 0L; var me = 0L; var rms: DoubleArray? = null; var step = 1
    val clips = ArrayList<Clip>(); val caps = ArrayList<Cap>(); val tls = ArrayList<TLayer>(); val ils = ArrayList<ILayer>()
    var chosen = Layout.SPLIT; var split = 0.4f; var swap = false
    val colors = listOf(Color.WHITE, Color.YELLOW, Color.RED, Color.GREEN, Color.CYAN, 0xFFFF9800.toInt())
    val msel = BooleanArray(4); var mLen = 30; var mK = 5
    var filterI = 0; var mute = false; var capOn = true; var capCol = 0; var capSize = 1; var capPos = 2; var capBg = true
    var resI = 1; var fpsI = 1; var brI = 0; var mergeI = 0
    var jobs = listOf<List<Clip>>(); var jobI = 0; var okN = 0; var failN = 0; var exporting = false; var lastErr = ""
    val h = Handler(Looper.getMainLooper())
    val prefs by lazy { getSharedPreferences("clipper", 0) }

    // ---------- UI helpers ----------
    fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    fun rr(c: Int, r: Int = 14) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    fun tv(t: String, sz: Float = 14f, c: Int = TX) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }
    fun head(t: String) = tv(t, 17f).apply { setTypeface(null, Typeface.BOLD); setPadding(0, dp(6), 0, dp(6)) }
    fun btn(t: String, filled: Boolean = false, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 13f; setTextColor(TX); background = rr(if (filled) AC else SF2); minHeight = 0; minimumHeight = 0
        setPadding(dp(14), dp(9), dp(14), dp(9)); layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
        setOnClickListener { f() }
    }
    fun sp(items: List<String>, init: Int, cb: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items); setSelection(init); background = rr(SF2, 10)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { cb(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }
    fun row(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; v.forEach { addView(it) } }
    fun col(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; v.forEach { addView(it) } }
    fun pnl(vararg v: View) = col(*v).apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }
    fun cbx(t: String, on: Boolean, cb: (Boolean) -> Unit) = CheckBox(this).apply { text = t; setTextColor(TX); isChecked = on; buttonTintList = ColorStateList.valueOf(AC); setOnCheckedChangeListener { _, v -> cb(v) } }
    fun edit(hint: String, def: String = "", num: Boolean = false) = EditText(this).apply {
        setText(def); this.hint = hint; setTextColor(TX); setHintTextColor(MU); background = rr(SF2, 10); setPadding(dp(12), dp(8), dp(12), dp(8))
        if (num) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
    }
    fun bar(max: Int, prog: Int, cb: (Int) -> Unit) = SeekBar(this).apply { this.max = max; progress = prog
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { cb(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
        }) }
    fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    fun fmtT(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }
    fun showBusy(m: String) { dlgText = tv(m).apply { setPadding(dp(24), dp(24), dp(24), dp(24)) }; dlg = AlertDialog.Builder(this).setView(dlgText).setCancelable(false).create(); dlg!!.show() }
    fun busy(m: String) = runOnUiThread { if (dlg != null) dlgText.text = m }
    fun hideBusy() { dlg?.dismiss(); dlg = null }

    // ---------- Screens ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG; window.navigationBarColor = BG
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(v: VideoSize) { mark.vw = maxOf(1, v.width); mark.vh = maxOf(1, v.height); mark.invalidate() }
            override fun onPlaybackStateChanged(s: Int) { if (s == Player.STATE_READY && me == 0L) { me = player.duration; upd() } }
        })
        mark = MarkView(this); prev = PreviewView(this)
        pf = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); addView(PlayerView(this@MainActivity).apply { this.player = this@MainActivity.player }); addView(mark) }
        areaInfo = tv("", 13f, MU)

        p1 = pnl(head("Step 1 of 3  ·  Mark areas"),
            tv("Import a video, pause on a frame where everything is visible, then mark the areas you want (1 = facecam, 2 = gameplay...). Drag a box to move it, drag its corner square to resize.", 13f, MU),
            row(btn("📥 Import video", true) { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "video/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 1) },
                btn("➕ Add area") { if (cur != null && mark.regs.size < 3) { val k = mark.regs.size * 0.05f; mark.regs.add(RectF(0.2f + k, 0.2f + k, 0.5f + k, 0.5f + k)); mark.act = mark.regs.size - 1; mark.invalidate(); areaInfo.text = "Areas marked: ${mark.regs.size}" } }),
            row(btn("🗑 Delete area") { if (mark.act >= 0) { mark.regs.removeAt(mark.act); mark.act = mark.regs.size - 1; mark.invalidate(); areaInfo.text = "Areas marked: ${mark.regs.size}" } },
                btn("Next  ›", true) { if (mark.regs.isEmpty()) areaInfo.text = "Add at least one area first" else go(2) }), areaInfo)

        val rg = RadioGroup(this)
        rbs = listOf("Single area (area 1 full screen)", "Split (area 1 top, area 2 bottom)", "3-part stack (areas 1, 2, 3)", "Picture-in-picture (area 1 over area 2)").mapIndexed { i, t ->
            RadioButton(this).apply { text = t; setTextColor(TX); id = View.generateViewId(); buttonTintList = ColorStateList.valueOf(AC); setOnClickListener { chosen = layouts[i]; refresh() } }.also { rg.addView(it) } }
        p2 = ScrollView(this).apply { addView(pnl(head("Step 2 of 3  ·  Choose layout"), prev.apply { layoutParams = LinearLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.5).toInt()) }, rg,
            cbx("Swap order of areas", false) { swap = it; refresh() }, tv("Size of first section", 13f, MU), bar(35, 15) { split = (25 + it) / 100f; refresh() },
            row(btn("‹  Back") { go(1) }, btn("Next  ›", true) { go(3) }))) }

        p3 = col(buildEditor())
        val root = col(pf, p1, p2, p3).apply { setBackgroundColor(BG) }
        p1.layoutParams = LinearLayout.LayoutParams(-1, -2); p2.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f); p3.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        setContentView(root); go(1)
    }

    fun buildEditor(): View {
        info = tv("", 13f, MU); clipsBox = col(); layersBox = col(); capInfo = tv("No subtitles yet", 13f, MU); expInfo = tv("", 13f, MU); status = tv("", 13f, MU)
        expBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }

        // Trim
        val db = edit("dB", "-30", true); val minMs = edit("ms", "500", true)
        val trim = pnl(info,
            row(btn("📍 Set start") { ms = player.currentPosition; upd() }, btn("📍 Set end") { me = player.currentPosition; upd() }),
            row(btn("➕ Add clip", true) { cur?.let { if (me > ms) { clips.add(Clip(it, ms, me)); rc() } } }, btn("✂️ Split here") { splitHere() }),
            tv("Silence cut keeps only the parts where someone is talking.", 12f, MU),
            row(tv("dB "), db, tv("  min ms "), minMs), btn("🔇 Cut silence") { silence(db.text.toString().toDoubleOrNull() ?: -30.0, minMs.text.toString().toLongOrNull() ?: 500) })

        // Clips
        val cl = pnl(row(btn("☑ All") { clips.forEach { it.on = true }; rc() }, btn("☐ None") { clips.forEach { it.on = false }; rc() }, btn("🗑 Clear auto") { clips.removeAll { it.auto }; rc() }), clipsBox)

        // Moments
        val mrow = Moments.TYPES.mapIndexed { i, t -> cbx("${Moments.ICONS[t]}  $t moments", false) { msel[i] = it } }
        val mom = pnl(head("Find moments"), tv("Tick one or more types, then press Add moments. Analysis uses the video's audio (loudness, bursts, calm speech).", 12f, MU),
            col(*mrow.toTypedArray()),
            row(tv("Length "), sp(listOf("15 sec", "30 sec", "45 sec", "60 sec"), 1) { mLen = listOf(15, 30, 45, 60)[it] }, tv("  Per type "), sp(listOf("Top 1", "Top 3", "Top 5", "Top 10"), 2) { mK = listOf(1, 3, 5, 10)[it] }),
            btn("✨ Add moments", true) { addMoments() })

        // Subtitles
        val key = edit("Groq API key (free)", prefs.getString("groq", "") ?: ""); key.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val langs = listOf("Auto-detect" to null, "Hindi" to "hi", "English" to "en", "Urdu" to "ur", "Bengali" to "bn", "Tamil" to "ta", "Telugu" to "te", "Marathi" to "mr", "Gujarati" to "gu", "Punjabi" to "pa", "Spanish" to "es", "Portuguese" to "pt", "Arabic" to "ar", "Indonesian" to "id", "Russian" to "ru", "Turkish" to "tr", "French" to "fr", "German" to "de", "Japanese" to "ja", "Korean" to "ko")
        var li = 0; var whole = 0
        val subs = pnl(head("Auto subtitles (any language)"), tv("Uses Whisper large-v3-turbo on Groq (free API key from console.groq.com/keys, internet needed).", 12f, MU), key,
            row(sp(langs.map { it.first }, 0) { li = it }, sp(listOf("Selected clips only", "Whole video"), 0) { whole = it }),
            btn("💬 Generate subtitles", true) { genSubs(key.text.toString().trim(), langs[li].second, whole == 1) }, capInfo,
            row(sp(listOf("White", "Yellow", "Red", "Green", "Cyan", "Orange"), 0) { capCol = it }, sp(listOf("Small", "Medium", "Large"), 1) { capSize = it }, sp(listOf("Top", "Middle", "Lower", "Bottom"), 2) { capPos = it }),
            cbx("Dark box behind text", true) { capBg = it }, cbx("Burn subtitles into export", true) { capOn = it })

        // Layers
        val txt = edit("Text or emoji (e.g. 🔥 FOLLOW)"); var tcol = 0; var tsz = 1; var tpos = 0; var tx = 1
        var isz = 1; var ipos = 1
        val lay = pnl(head("Layers (applied to every clip)"), txt,
            row(sp(listOf("White", "Yellow", "Red", "Green", "Cyan", "Orange"), 1) { tcol = it }, sp(listOf("Small", "Medium", "Large"), 1) { tsz = it }, sp(listOf("Top", "Middle", "Bottom"), 0) { tpos = it }, sp(listOf("Left", "Center", "Right"), 1) { tx = it }),
            btn("🔤 Add text layer", true) { if (txt.text.isNotBlank()) { tls.add(TLayer(txt.text.toString(), colors[tcol], listOf(0.05f, 0.07f, 0.1f)[tsz], listOf(-0.6f, 0f, 0.6f)[tx], listOf(0.8f, 0f, -0.8f)[tpos])); txt.setText(""); rl() } },
            row(sp(listOf("Small logo", "Medium", "Large"), 1) { isz = it }, sp(listOf("Top-left", "Top-right", "Bottom-left", "Bottom-right", "Center"), 1) { ipos = it }, btn("🖼 Image") {
                pendingImg = { bm -> val x = listOf(-0.75f, 0.75f, -0.75f, 0.75f, 0f)[ipos]; val y = listOf(0.8f, 0.8f, -0.8f, -0.8f, 0f)[ipos]; ils.add(ILayer(bm, listOf(0.15f, 0.25f, 0.4f)[isz], x, y)); rl() }
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 2) }), layersBox)

        // Filters
        val names = listOf("Original", "B&W", "Warm", "Cool", "Vivid", "Bright"); val fb = ArrayList<Button>()
        names.forEachIndexed { i, n -> fb.add(btn(n, i == 0) { filterI = i; fb.forEachIndexed { k, b -> b.background = rr(if (k == i) AC else SF2) } }) }
        val flt = pnl(head("Filters"), HorizontalScrollView(this).apply { addView(row(*fb.toTypedArray())) }, cbx("Mute original audio", false) { mute = it })

        // Export
        val exp = pnl(head("Export"), expInfo,
            row(tv("Mode "), sp(listOf("Separate videos (fast, safe)", "Merge into one video"), 0) { mergeI = it }),
            row(tv("Quality "), sp(listOf("Fast 480p", "Balanced 720p", "HD 1080p"), 1) { resI = it }, tv("  FPS "), sp(listOf("24", "30"), 1) { fpsI = it }),
            row(tv("Bitrate "), sp(listOf("Auto", "2 Mbps", "4 Mbps", "6 Mbps", "8 Mbps", "12 Mbps"), 0) { brI = it }),
            btn("📤 Export selected clips", true) { startExport() }, expBar, status)

        panels = listOf(trim, cl, mom, subs, lay, flt, exp).map { ScrollView(this).apply { addView(it); setBackgroundColor(BG) } }
        val box = FrameLayout(this).apply { panels.forEach { addView(it) } }
        val tools = listOf("✂️" to "Trim", "🎞️" to "Clips", "✨" to "Moments", "💬" to "Subtitles", "🧩" to "Layers", "🎨" to "Filters", "📤" to "Export")
        tiles = tools.mapIndexed { i, t ->
            col(tv(t.first, 22f).apply { gravity = Gravity.CENTER }, tv(t.second, 11f, MU).apply { gravity = Gravity.CENTER }).apply {
                setPadding(dp(14), dp(8), dp(14), dp(8)); background = rr(SF2); setOnClickListener { showPanel(i) }
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) } }
        }
        val tb = HorizontalScrollView(this).apply { setBackgroundColor(SF); addView(row(*tiles.toTypedArray())) }
        showPanel(0)
        return col(box.apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }, tb)
    }

    var pendingImg: ((Bitmap) -> Unit)? = null
    fun showPanel(i: Int) { panels.forEachIndexed { k, p -> p.visibility = if (k == i) View.VISIBLE else View.GONE }; tiles.forEachIndexed { k, t -> t.background = rr(if (k == i) AC else SF2) } }

    fun go(n: Int) {
        step = n; val H = resources.displayMetrics.heightPixels
        pf.visibility = if (n == 2) View.GONE else View.VISIBLE; mark.visibility = if (n == 1) View.VISIBLE else View.GONE
        pf.layoutParams = LinearLayout.LayoutParams(-1, (H * (if (n == 1) 0.45 else 0.34)).toInt())
        p1.visibility = if (n == 1) View.VISIBLE else View.GONE; p2.visibility = if (n == 2) View.VISIBLE else View.GONE; p3.visibility = if (n == 3) View.VISIBLE else View.GONE
        if (n == 2) {
            player.pause()
            val mr = MediaMetadataRetriever(); try { mr.setDataSource(this, cur); prev.bmp = mr.getFrameAtTime(player.currentPosition * 1000, MediaMetadataRetriever.OPTION_CLOSEST) } catch (_: Exception) {} finally { mr.release() }
            rbs.forEachIndexed { i, rb -> rb.isEnabled = mark.regs.size >= need[i] }
            if (mark.regs.size < need[layouts.indexOf(chosen)]) chosen = if (mark.regs.size >= 2) Layout.SPLIT else Layout.SINGLE
            rbs[layouts.indexOf(chosen)].isChecked = true; refresh()
        }
        if (n == 3) { upd(); rc() }
    }
    fun refresh() { prev.regs = mark.regs.map { RectF(it) }; prev.lay = chosen; prev.split = split; prev.swap = swap; prev.invalidate() }
    override fun onBackPressed() { if (step > 1) go(step - 1) else super.onBackPressed() }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        val u = d?.data ?: return
        if (rq == 2) {
            try { val o = BitmapFactory.Options().apply { inSampleSize = 2 }; contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o) }?.let { pendingImg?.invoke(it) } } catch (e: Exception) { toast("Image error: ${e.message}") }
            return
        }
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        cur = u; ms = 0; me = 0; rms = null; clips.clear(); caps.clear(); mark.regs.clear(); mark.act = -1; areaInfo.text = "Areas marked: 0"
        player.setMediaItem(MediaItem.fromUri(u)); player.prepare(); mark.invalidate()
    }
    fun upd() { info.text = "Start ${fmtT(ms)}   End ${fmtT(me)}" }

    // ---------- Clips ----------
    fun splitHere() {
        val u = cur ?: return; val t = player.currentPosition
        var i = clips.indexOfFirst { it.uri == u && t > it.s && t < it.e }
        if (i < 0) { clips.add(Clip(u, 0, player.duration)); i = clips.size - 1 }
        val c = clips[i]; clips[i] = c.copy(e = t); clips.add(i + 1, c.copy(s = t, tag = "")); rc()
    }
    fun rc() {
        clipsBox.removeAllViews()
        clips.forEachIndexed { i, c ->
            clipsBox.addView(row(cbx("", c.on) { c.on = it; updExp() }, tv("${i + 1}. ${c.tag} ${fmtT(c.s)}–${fmtT(c.e)}", 13f).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) },
                btn("▶") { go(3); player.seekTo(c.s); player.play() }, btn("🗑") { clips.removeAt(i); rc() }))
        }
        if (clips.isEmpty()) clipsBox.addView(tv("No clips yet. Use Trim, Moments or Cut silence.", 13f, MU))
        updExp()
    }
    fun updExp() { if (::expInfo.isInitialized) { val s = clips.filter { it.on }; expInfo.text = "${s.size} clips selected · ${fmtT(s.sumOf { it.e - it.s })} total" } }
    fun rl() {
        layersBox.removeAllViews()
        tls.forEachIndexed { i, t -> layersBox.addView(row(tv("🔤 ${t.text}", 13f).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }, btn("🗑") { tls.removeAt(i); rl() })) }
        ils.forEachIndexed { i, _ -> layersBox.addView(row(tv("🖼 Image ${i + 1}", 13f).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }, btn("🗑") { ils.removeAt(i); rl() })) }
    }

    // ---------- Analysis ----------
    fun analyze(msg: String, done: (DoubleArray) -> Unit) {
        val u = cur ?: run { toast("Import a video first"); return }; val dur = player.duration
        rms?.let { done(it); return }
        showBusy("$msg\nReading audio... 0%")
        Thread {
            try { val r = audioRms(this, u, dur) { p -> busy("$msg\nReading audio... $p%") }; runOnUiThread { rms = r; hideBusy(); done(r) } }
            catch (e: Exception) { runOnUiThread { hideBusy(); toast("Analysis failed: ${e.message}") } }
        }.start()
    }
    fun silence(thrDb: Double, minSilMs: Long) = analyze("Cutting silence") { r ->
        val u = cur!!; val thr = Math.pow(10.0, thrDb / 20); val gap = (minSilMs / 50).toInt().coerceAtLeast(1)
        val out = ArrayList<Pair<Long, Long>>(); var st = -1; var last = -1
        for (i in r.indices) if (r[i] >= thr) { if (st < 0) st = i else if (i - last > gap) { out.add(Pair(st * 50L, (last + 1) * 50L)); st = i }; last = i }
        if (st >= 0) out.add(Pair(st * 50L, (last + 1) * 50L))
        val dur = player.duration
        out.map { Pair((it.first - 50).coerceAtLeast(0), (it.second + 50).coerceAtMost(dur)) }.filter { it.second - it.first > 300 }.forEach { clips.add(Clip(u, it.first, it.second, "🔇")) }
        rc(); showPanel(1)
    }
    fun addMoments() {
        val types = Moments.TYPES.filterIndexed { i, _ -> msel[i] }
        if (types.isEmpty()) { toast("Tick at least one moment type"); return }
        analyze("Analyzing full video for: ${types.joinToString()}") { r ->
            val hits = Moments.find(r, types, mLen, mK); val u = cur!!; val dur = player.duration
            clips.removeAll { it.auto }
            hits.forEach { clips.add(Clip(u, it.startS * 1000L, minOf(dur, it.endS * 1000L), "${Moments.ICONS[it.type]} ${it.type} #${it.rank}", true)) }
            rc(); showPanel(1); toast(if (hits.isEmpty()) "No strong moments found" else "${hits.size} moments added")
        }
    }

    // ---------- Subtitles ----------
    fun genSubs(key: String, lang: String?, whole: Boolean) {
        val u = cur ?: run { toast("Import a video first"); return }
        if (key.isBlank()) { toast("Paste your free Groq API key first"); return }
        prefs.edit().putString("groq", key).apply()
        val d = player.duration
        val raw = if (whole) (0 until ((d + 599999) / 600000).toInt()).map { Pair(it * 600000L, minOf(d, (it + 1) * 600000L)) } else clips.filter { it.on }.map { Pair(it.s, it.e) }.sortedBy { it.first }
        val ranges = ArrayList<Pair<Long, Long>>()
        raw.forEach { r -> if (ranges.isNotEmpty() && r.first <= ranges.last().second) ranges[ranges.size - 1] = Pair(ranges.last().first, maxOf(ranges.last().second, r.second)) else ranges.add(r) }
        if (ranges.isEmpty()) { toast("Add clips first, or choose Whole video"); return }
        showBusy("Generating subtitles...")
        Thread {
            try {
                val all = ArrayList<Cap>(); val f = File(cacheDir, "a.m4a")
                ranges.forEachIndexed { i, r ->
                    busy("Generating subtitles ${i + 1}/${ranges.size}")
                    val off = extractAudio(this, u, r.first, r.second, f); all.addAll(toCaps(whisper(key, f, lang), off))
                    Thread.sleep(if (ranges.size > 15) 3200 else 300)
                }
                runOnUiThread { caps.clear(); caps.addAll(all); hideBusy(); capInfo.text = "${caps.size} subtitle lines ready"; if (caps.isEmpty()) toast("No speech found") }
            } catch (e: Exception) { runOnUiThread { hideBusy(); toast("Subtitles failed: ${e.message}") } }
        }.start()
    }

    // ---------- Export ----------
    fun textOverlay(sp: SpannableString, x: Float, y: Float): TextureOverlay {
        val st = OverlaySettings.Builder().setBackgroundFrameAnchor(x, y).build()
        return object : TextOverlay() { override fun getText(us: Long) = sp; override fun getOverlaySettings(us: Long) = st }
    }
    fun styled(t: String, color: Int, px: Int, bg: Boolean, bold: Boolean): SpannableString = SpannableString(t).apply {
        setSpan(ForegroundColorSpan(color), 0, length, 0); setSpan(AbsoluteSizeSpan(px), 0, length, 0)
        if (bold) setSpan(StyleSpan(Typeface.BOLD), 0, length, 0); if (bg) setSpan(BackgroundColorSpan(0xB3000000.toInt()), 0, length, 0)
    }
    fun item(c: Clip, ow: Int, oh: Int, fps: Int): EditedMediaItem {
        val mi = MediaItem.Builder().setUri(c.uri).setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.s).setEndPositionMs(c.e).build()).build()
        val v = ArrayList<Effect>()
        v.add(LayoutEffect(mark.regs.map { RectF(it) }, chosen, split, swap, ow, oh))
        when (filterI) {
            1 -> v.add(RgbFilter.createGrayscaleFilter())
            2 -> v.add(RgbAdjustment.Builder().setRedScale(1.12f).setBlueScale(0.88f).build())
            3 -> v.add(RgbAdjustment.Builder().setRedScale(0.88f).setBlueScale(1.12f).build())
            4 -> v.add(Contrast(0.25f))
            5 -> v.add(Brightness(0.12f))
        }
        if (fps < 30) v.add(FrameDropEffect.createDefaultFrameDropEffect(fps.toFloat()))
        val ov = ArrayList<TextureOverlay>()
        if (capOn) {
            val cc = caps.filter { it.e > c.s && it.s < c.e }
            if (cc.isNotEmpty()) {
                val px = (ow * listOf(0.055f, 0.07f, 0.09f)[capSize]).toInt(); val spans = cc.map { styled(it.t, colors[capCol], px, capBg, true) }
                val st = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, listOf(0.75f, 0f, -0.45f, -0.75f)[capPos]).build()
                ov.add(object : TextOverlay() {
                    val off = SpannableString(" ")
                    override fun getText(us: Long): SpannableString { val m = us / 1000 + c.s; val i = cc.indexOfFirst { m >= it.s && m <= it.e }; return if (i >= 0) spans[i] else off }
                    override fun getOverlaySettings(us: Long) = st
                })
            }
        }
        tls.forEach { ov.add(textOverlay(styled(it.text, it.color, (ow * it.size).toInt(), false, true), it.x, it.y)) }
        ils.forEach { il ->
            val w = (ow * il.frac).toInt().coerceAtLeast(8); val hh = (w.toFloat() * il.bmp.height / il.bmp.width).toInt().coerceAtLeast(8)
            val bm = Bitmap.createScaledBitmap(il.bmp, w, hh, true); val st = OverlaySettings.Builder().setBackgroundFrameAnchor(il.x, il.y).build()
            ov.add(object : BitmapOverlay() { override fun getBitmap(us: Long): Bitmap = bm; override fun getOverlaySettings(us: Long) = st })
        }
        if (ov.isNotEmpty()) v.add(OverlayEffect(ImmutableList.copyOf<TextureOverlay>(ov)))
        return EditedMediaItem.Builder(mi).setRemoveAudio(mute).setEffects(Effects(emptyList(), v)).build()
    }

    fun startExport() {
        if (exporting) return
        val sel = clips.filter { it.on }; if (sel.isEmpty()) { toast("Select at least one clip"); return }
        jobs = if (mergeI == 1) listOf(sel) else sel.map { listOf(it) }
        jobI = 0; okN = 0; failN = 0; lastErr = ""; exporting = true; nextJob()
    }
    fun nextJob() {
        if (jobI >= jobs.size) {
            exporting = false; expBar.progress = 100
            status.text = "Finished: $okN saved to Movies/Clipper" + (if (failN > 0) ", $failN failed ($lastErr)" else ""); return
        }
        val ow = listOf(480, 720, 1080)[resI]; val oh = (ow * 16 / 9) / 2 * 2; val fps = listOf(24, 30)[fpsI]
        val mbps = if (brI == 0) listOf(2f, 4f, 8f)[resI] else listOf(0f, 2f, 4f, 6f, 8f, 12f)[brI]
        val out = File(cacheDir, "out_$jobI.mp4"); out.delete(); val my = jobI
        val vs = VideoEncoderSettings.Builder().setBitrate((mbps * 1_000_000).toInt()).build()
        val tr = Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setMaxDelayBetweenMuxerSamplesMs(C.TIME_UNSET)
            .setEncoderFactory(DefaultEncoderFactory.Builder(this).setRequestedVideoEncoderSettings(vs).build())
            .addListener(object : Transformer.Listener {
                override fun onCompleted(c: Composition, er: ExportResult) { try { save(out, my); okN++ } catch (e: Exception) { failN++; lastErr = "save: ${e.message}" }; jobI++; nextJob() }
                override fun onError(c: Composition, er: ExportResult, e: ExportException) { failN++; lastErr = "${e.errorCodeName} ${e.cause?.message ?: ""}".trim(); jobI++; nextJob() }
            }).build()
        try {
            val comp = Composition.Builder(EditedMediaItemSequence(jobs[my].map { item(it, ow, oh, fps) })).build()
            tr.start(comp, out.absolutePath)
        } catch (e: Exception) { failN++; lastErr = e.message ?: "start failed"; jobI++; nextJob(); return }
        val ph = ProgressHolder()
        h.post(object : Runnable { override fun run() {
            if (!exporting || jobI != my) return
            tr.getProgress(ph); status.text = "Exporting ${my + 1}/${jobs.size}  ·  ${ph.progress}%"
            expBar.progress = (my * 100 + ph.progress) / jobs.size; h.postDelayed(this, 500)
        } })
    }
    fun save(f: File, n: Int) {
        val cv = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, "clip_${System.currentTimeMillis()}_$n.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4"); put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Clipper") }
        val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
        contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        f.delete()
    }
}
