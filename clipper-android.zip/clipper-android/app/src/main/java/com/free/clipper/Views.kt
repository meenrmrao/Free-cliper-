package com.free.clipper

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

fun fitRect(w: Float, h: Float, vw: Int, vh: Int): RectF {
    val a = vw.toFloat() / vh; val rw = if (w / h > a) h * a else w; val rh = if (w / h > a) h else w / a
    return RectF((w - rw) / 2, (h - rh) / 2, (w + rw) / 2, (h + rh) / 2)
}

/** Draw / move / resize up to 3 areas on top of the video. Touches outside the boxes pass through to the video. */
class MarkView(c: Context) : View(c) {
    var vw = 16; var vh = 9; val regs = ArrayList<RectF>(); var act = -1; var onChange: (() -> Unit)? = null
    private val cols = intArrayOf(0xFF34C759.toInt(), 0xFF00E5FF.toInt(), 0xFFFFD60A.toInt())
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f }
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 52f; isFakeBoldText = true }
    private var lx = 0f; private var ly = 0f; private var mode = 0
    override fun onDraw(c: Canvas) {
        val r = fitRect(width.toFloat(), height.toFloat(), vw, vh)
        regs.forEachIndexed { i, g ->
            val b = RectF(r.left + g.left * r.width(), r.top + g.top * r.height(), r.left + g.right * r.width(), r.top + g.bottom * r.height())
            p.style = Paint.Style.FILL; p.color = (cols[i] and 0x00FFFFFF) or 0x22000000; c.drawRect(b, p)
            p.style = Paint.Style.STROKE; p.color = cols[i]; p.strokeWidth = if (i == act) 8f else 4f; c.drawRect(b, p)
            t.color = cols[i]; c.drawText("${i + 1}", b.left + 12, b.top + 52, t)
            if (i == act) { p.style = Paint.Style.FILL; c.drawCircle(b.right, b.bottom, 20f, p); p.style = Paint.Style.STROKE }
        }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val r = fitRect(width.toFloat(), height.toFloat(), vw, vh)
        val nx = (e.x - r.left) / r.width(); val ny = (e.y - r.top) / r.height()
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                lx = e.x; ly = e.y; mode = 0
                val a = regs.getOrNull(act)
                if (a != null && Math.abs(e.x - (r.left + a.right * r.width())) < 80 && Math.abs(e.y - (r.top + a.bottom * r.height())) < 80) mode = 2
                else { val i = regs.indexOfLast { it.contains(nx, ny) }; if (i >= 0) { act = i; mode = 1; invalidate() } }
                if (mode == 0) return false
                parent.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                val g = regs.getOrNull(act) ?: return true
                val dx = (e.x - lx) / r.width(); val dy = (e.y - ly) / r.height(); lx = e.x; ly = e.y
                if (mode == 1) { val ddx = dx.coerceIn(-g.left, 1f - g.right); val ddy = dy.coerceIn(-g.top, 1f - g.bottom); g.offset(ddx, ddy) }
                if (mode == 2) { g.right = (g.right + dx).coerceIn(g.left + 0.05f, 1f); g.bottom = (g.bottom + dy).coerceIn(g.top + 0.05f, 1f) }
                invalidate(); onChange?.invoke()
            }
        }
        return true
    }
}

/** Shows the chosen layout on a real video frame in the output aspect ratio */
class PreviewView(c: Context) : View(c) {
    var bmp: Bitmap? = null; var regs: List<RectF> = emptyList(); var lay = Layout.SINGLE; var split = 0.4f; var swap = false; var ar = 9f / 16
    private val bg = Paint().apply { color = Color.BLACK }
    private val bd = Paint().apply { color = 0xFF4A5160.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f }
    override fun onDraw(c: Canvas) {
        var oh = height * 0.96f; var ow = oh * ar
        if (ow > width * 0.98f) { ow = width * 0.98f; oh = ow / ar }
        val x0 = (width - ow) / 2; val y0 = (height - oh) / 2
        c.drawRect(x0, y0, x0 + ow, y0 + oh, bg)
        val b = bmp
        if (b != null && regs.isNotEmpty()) {
            buildLayers(b.width, b.height, regs, lay, split, swap, (ar * 1000).toInt(), 1000).forEach { l ->
                val src = Rect((l.src.left * b.width).toInt(), (l.src.top * b.height).toInt(), (l.src.right * b.width).toInt(), (l.src.bottom * b.height).toInt())
                val dst = RectF(x0 + l.out.left * ow, y0 + l.out.top * oh, x0 + l.out.right * ow, y0 + l.out.bottom * oh)
                c.drawBitmap(b, src, dst, null)
            }
        }
        c.drawRect(x0, y0, x0 + ow, y0 + oh, bd)
    }
}
